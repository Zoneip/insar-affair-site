"""DANI-NET reproduction - global configuration.

Reference: G. Costa, A. V. Monti Guarnieri, A. Parizzi, P. Rizzoli,
"DANI-NET: A Physics-Aware Deep Learning Framework for Change Detection
using Repeat-Pass InSAR", IEEE TGRS (submitted/preprint), 2025.

Section references ("Sec. II-C", "Eq. (17)", "Alg. 1", ...) point to the paper.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field, asdict
from typing import List, Tuple

import numpy as np

# ----------------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------------
ROOT = os.path.dirname(os.path.abspath(__file__))
CACHE_DIR = os.path.join(ROOT, "data", "cache")
RUNS_DIR = os.path.join(ROOT, "runs")
OUT_DIR = os.path.join(ROOT, "out")
for _d in (CACHE_DIR, RUNS_DIR, OUT_DIR):
    os.makedirs(_d, exist_ok=True)


# ----------------------------------------------------------------------------
# 1. Physical constants of the synthetic scene  (Sec. II-C, III, Table II)
# ----------------------------------------------------------------------------
@dataclass
class PhysicsCfg:
    # Temporal bandwidth Bw: number of consecutive acquisitions in a window.
    Bw: int = 4

    # Incidence angle range of the sensor (Table II): theta in [25, 55] deg.
    theta_min_deg: float = 25.0
    theta_max_deg: float = 55.0

    # Local incidence angle range (Table II): theta_L in [5, 80] deg.
    thetaL_min_deg: float = 5.0
    thetaL_max_deg: float = 80.0

    # Normalised baseline ratio Bn/Bc ~ U[-0.15, 0.15]  (Table II, Eq. (7)).
    bn_bc_min: float = -0.15
    bn_bc_max: float = 0.15

    # Temporal decorrelation ratio tau/tr in {0,1,2,3} (Table II, Eq. (6)).
    tau_ratio_set: Tuple[int, ...] = (0, 1, 2, 3)

    # Number of looks over which the coherence matrix is estimated (Table II).
    L_train: Tuple[int, ...] = (9, 16, 36, 121)
    # Test also uses L = 25, 49 which are NEVER seen during training (Sec. V-D).
    L_test: Tuple[int, ...] = (9, 16, 25, 36, 49, 121)

    # Maximum theoretical coherence gamma_0 (Eq. (5)). The paper does not state
    # an explicit number; a slightly imperfect value is used so that class-0
    # targets are not unrealistically perfect.
    gamma0: float = 0.98

    # Which mean-backscatter model to use (Sec. III-A): "ulaby" or "tandem".
    backscatter_model: str = "tandem"


# ----------------------------------------------------------------------------
# 2. Backscatter models (Sec. III-A, Eq. (17)-(18), Table I)
# ----------------------------------------------------------------------------
# sigma0 = P1 + P2 exp(-P3 theta) + P4 cos(P5 theta + P6)   [theta in rad]
# The paper re-phrases this in terms of radar brightness beta0 via Eq. (2).
ULABY_P = (4.337, 6.666, -0.107, -29.709, 0.863, -1.365)

# "TanDEM-beta0": Eq. (18), fitted directly in radar-brightness (beta0) dB.
# Unlike ULABY_P, these coefficients must not receive another
# ``-10*log10(sin(theta_L))`` conversion.  The negative P3 is intentional;
# theta is in radians and the resulting curve is in the same plausible range
# as the values shown in Fig. 3.
TANDEM_P = (67.22517, -69.2009, -0.1460, 0.6554, 8.5069, -3.1548)

# beta0 validity range enforced by the generator (Eq. (4) calibration domain).
BETA0_DB_MIN = -35.0
BETA0_DB_MAX = 10.0

# Coherence value retained inside a "different radar object" block (the eps of
# Eqs. (9), (10), (15) and of the threshold in [15]). The paper does not fix its
# value; 0.05 represents a fully decorrelated couple while keeping the
# coherence matrix numerically well conditioned.
EPSILON_LOW = 0.05

# Maximum theoretical coherence gamma_0 = 0.98 is defined in PhysicsCfg; this
# module-level alias is used as the default in the physics helpers.
GAMMA0 = 0.98


# ----------------------------------------------------------------------------
# 3. Classes of change (Sec. IV-A, Fig. 4)
# ----------------------------------------------------------------------------
# icp = 0 : Class 0 - Always Coherent (AC) / Never Coherent (NC)   -> no change
# icp = 1 : Class 1 - Dynamic change after 1st acquisition (DYN-1)
# icp = 2 : Class 2 - Dynamic change after 2nd acquisition (DYN-2)
# icp = 3 : Class 3 - Dynamic change after 3rd acquisition (DYN-3)
#                     + Appearing-Disappearing Coherent Scatterer (ADCS)
N_CLASSES = 4

# Realisations of the change patterns inside each class (Sec. IV-A).
# "gain"/"loss" = the post-change radar object gains/loses coherence with the
# initial one (i.e. spectra of CS / DCS scatterers of [15]).
CHANGE_TYPES = {
    0: ("AC", "NC"),
    1: ("DYN1_gain", "DYN1_loss"),
    2: ("DYN2_gain", "DYN2_loss"),
    3: ("DYN3_gain", "DYN3_loss", "ADCS"),
}

# Probability of a pixel being affected by a change (the paper balances the
# dataset 50/50 between changed and unchanged pixels - Fig. 11).
P_CHANGE = 0.5


# ----------------------------------------------------------------------------
# 4. Dataset / patch geometry (Sec. IV-C)
# ----------------------------------------------------------------------------
@dataclass
class DataCfg:
    patch: int = 128          # [128 x 128 x 10] tensors (Sec. IV-C)
    tile: int = 16            # 16x16 pilot patch used to fill the scene (Sec. V-D)
    # The paper fills 1000 tiles per patch (Sec. IV-C / V-B). We keep the tile
    # level vectorisation instead (mathematically identical, see README).
    n_tiles_fill: int = 1
    amplitude_normalization: Tuple[float, float] = (-40.0, 5.0)  # dB domain
    # A spatial pattern covers about 55% of a pilot tile.  The generator uses
    # this expectation to choose changed tiles so the resulting pixel labels
    # are close to the 50/50 changed/unchanged distribution in Fig. 11.
    expected_change_coverage: float = 0.55


# ----------------------------------------------------------------------------
# 5. DANI-NET architecture (Sec. V-A, Fig. 7, Table IV)
# ----------------------------------------------------------------------------
@dataclass
class NetCfg:
    in_channels: int = 10     # 4 amplitude + 6 coherence (Sec. V-A)
    hidden_channels: int = 128
    # intermediate width of the two 1x1 convolutions of the input block
    # ("gradually increase the number of feature maps up to 128", Sec. V-A).
    # 16 reproduces the trainable-parameter budget of Table IV to within 0.01 %.
    stem_channels: int = 16
    n_hidden_blocks: int = 5  # DANI-NET "5" is the operative model (Sec. VII-B)
    dropout: float = 0.5
    n_classes: int = N_CLASSES


# ----------------------------------------------------------------------------
# 6. Training (Sec. V-B, Eq. (35))
# ----------------------------------------------------------------------------
@dataclass
class TrainCfg:
    batch_size: int = 32
    lr: float = 1e-4
    lr_drops: Tuple[Tuple[int, float], ...] = ((14, 1e-5), (24, 1e-6))
    max_epochs: int = 250
    early_stop_patience: int = 16
    seed: int = 0
    val_fraction: float = 0.2
    num_workers: int = 0
    log_every: int = 50
    amp: bool = True          # mixed precision
    # Patch budget (reproduction scale knob). The paper uses ~1.5e6 patches for
    # training per look and ~3.0e6 for the augmented run.
    n_train_patches: int = 40000
    n_val_patches: int = 5000


@dataclass
class Cfg:
    physics: PhysicsCfg = field(default_factory=PhysicsCfg)
    data: DataCfg = field(default_factory=DataCfg)
    net: NetCfg = field(default_factory=NetCfg)
    train: TrainCfg = field(default_factory=TrainCfg)

    def to_dict(self):
        return asdict(self)


def default_cfg() -> Cfg:
    return Cfg()


# ----------------------------------------------------------------------------
# Helpers shared by the generator
# ----------------------------------------------------------------------------
def beta0_from_theta(theta_rad: np.ndarray, model: str = "tandem") -> np.ndarray:
    """Radar brightness beta0 [dB] from the incidence angle theta [rad].

    Implements Eq. (17) re-phrased in terms of beta0 (Eq. (2)), i.e. the
    "Ulaby" model, or the re-fitted "TanDEM-beta0" model of Eq. (18).
    """
    P1, P2, P3, P4, P5, P6 = TANDEM_P if model == "tandem" else ULABY_P
    fit_db = P1 + P2 * np.exp(-P3 * theta_rad) + P4 * np.cos(P5 * theta_rad + P6)
    if model == "tandem":
        # Eq. (18) is already a beta0 fit.
        return fit_db
    # Eq. (17) is a sigma0 fit; the flat-reference beta0 uses theta_L ~= theta.
    return fit_db - 10.0 * np.log10(np.maximum(np.sin(theta_rad), 1e-6))
