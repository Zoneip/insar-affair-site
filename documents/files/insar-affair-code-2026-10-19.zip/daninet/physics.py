"""Physical modelling layer of the DANI-NET reproduction.

Implements:
  * the mean backscatter models of Sec. III-A (Eq. (17)-(18), Table I);
  * the coherence factorisation of Eq. (5)-(7);
  * the radar-brightness re-scaling of Eq. (29)-(33).

All angles are handled in radians internally.
"""
from __future__ import annotations

import numpy as np

from . import config as C

EPS = 1e-12


# ---------------------------------------------------------------------------
# Backscatter (Sec. III-A)
# ---------------------------------------------------------------------------
def beta0_db(theta_rad, theta_l_rad=None, model: str = "tandem"):
    """Radar brightness beta0 in dB for incidence and local incidence angles.

    Eq. (17) is a sigma0 fit (Ulaby), so it is converted with
    ``beta0=sigma0/sin(theta_L)``.  Eq. (18) is already a direct beta0 fit for
    TanDEM-X; a non-flat local angle is applied through the same ratio used by
    Eq. (29), while the fitted incidence angle remains ``theta_rad``.
    """
    # Backward-compatible shorthand beta0_db(theta, "ulaby").
    if isinstance(theta_l_rad, str):
        model, theta_l_rad = theta_l_rad, None
    theta_rad = np.asarray(theta_rad, dtype=np.float64)
    if theta_l_rad is None:
        theta_l_rad = theta_rad
    theta_l_rad = np.asarray(theta_l_rad, dtype=np.float64)
    P1, P2, P3, P4, P5, P6 = C.TANDEM_P if model == "tandem" else C.ULABY_P
    fit_db = P1 + P2 * np.exp(-P3 * theta_rad) + P4 * np.cos(P5 * theta_rad + P6)
    if model == "tandem":
        # Eq. (18) is fitted for the flat reference theta_L ~= theta.
        return fit_db - 10.0 * np.log10(
            np.maximum(np.sin(theta_l_rad) / np.sin(theta_rad), EPS))
    return fit_db - 10.0 * np.log10(np.maximum(np.sin(theta_l_rad), EPS))


def beta0_db_shifted(theta_rad, theta_l_rad, delta_alpha_rad,
                     model: str = "tandem"):
    """beta0 in dB after a terrain-slope variation delta_alpha (Eq. (29)).

    With theta_L^(1) = theta_L^(0) + delta_alpha and
    beta0^(1) = beta0^(0) / K(theta_L^(0), delta_alpha), K = sin(theta_L^(1)) /
    sin(theta_L^(0)).  In dB this is simply
        beta0^(1)|dB = beta0^(0)|dB - 10 log10(sin(theta_L^(1))/sin(theta_L^(0))).
    """
    theta_rad = np.asarray(theta_rad, dtype=np.float64)
    theta_l_rad = np.asarray(theta_l_rad, dtype=np.float64)
    delta_alpha_rad = np.asarray(delta_alpha_rad, dtype=np.float64)
    b0 = beta0_db(theta_rad, theta_l_rad, model)
    ratio = np.sin(theta_l_rad + delta_alpha_rad) / np.sin(theta_l_rad)
    return b0 - 10.0 * np.log10(np.maximum(ratio, EPS))


# ---------------------------------------------------------------------------
# Coherence factors (Eq. (5)-(7))
# ---------------------------------------------------------------------------
def gamma_temporal(tau_ratio: int, n: int) -> np.ndarray:
    """Temporal decorrelation gamma_t for an n-epoch window (Eq. (6)).

    Eq. (6) is ``gamma_t = exp(-|Bt_ij| / tau)`` with ``Bt_ij = |i - j| * tr``
    (the temporal baseline in days) and ``tau`` the temporal decorrelation
    constant.  Writing the dimensionless ratio ``tau/tr`` listed in Table II,

        gamma_t^(ij) = exp(- |i - j| / (tau/tr))

    so a LARGER tau/tr means a SLOWER decorrelation - consistently with Sec. VIII
    ("the slower the temporal decorrelation, i.e., the higher tau/tr, the higher
    the importance of the long-term coherence samples").

    tau/tr = 0 (also listed in Table II) is the limit of an infinitely fast
    decorrelation and is implemented as a very small ratio, giving gamma_t ~ 0
    for any non-zero temporal baseline.
    """
    k = float(tau_ratio)
    if k <= 0.0:
        k = 0.02
    idx = np.arange(n, dtype=np.float64)
    lag = np.abs(idx[:, None] - idx[None, :])
    return np.exp(-lag / k)


def gamma_spatial(bn_bc) -> np.ndarray:
    """Geometric decorrelation gamma_b = 1 - Bn/Bc  (Eq. (7))."""
    return 1.0 - np.asarray(bn_bc, dtype=np.float64)


# ---------------------------------------------------------------------------
# Change patterns inside the coherence matrix (Sec. II-B, IV-A, Fig. 4)
# ---------------------------------------------------------------------------
def change_pattern(name: str, n: int, eps: float = C.EPSILON_LOW) -> np.ndarray:
    """Binary mask multiplying the ideal coherence matrix (Sec. II-B, IV-A).

    A value of 1 keeps the ideal coherence (same radar object), ``eps``
    decorrelates the couple (two different radar objects).

    The realisation is ``loss`` when the object that exists before the change
    loses coherence with the new one, and ``gain`` when the object appearing
    after the change is the one that gains coherence (the two are the transpose
    of each other, cf. the CS/DCS scatterers of [15]).  In both cases the epoch
    at the change is drawn with the *new* object, so the break between the two
    blocks is placed between ``icp`` and ``icp + 1``:

        mask = (i <= icp) & (j > icp)      [loss]
        mask = (i < icp)  & (j >= icp)     [gain]
    """
    idx = np.arange(n)
    if name == "AC":
        return np.ones((n, n))
    if name == "NC":
        m = np.full((n, n), eps)
        np.fill_diagonal(m, 1.0)
        return m
    if name == "ADCS":
        # coherent island only between icp and icp+1 (an independent object)
        icp = 2
        m = np.full((n, n), eps)
        np.fill_diagonal(m, 1.0)
        m[icp, icp + 1] = m[icp + 1, icp] = 1.0
        return m

    icp = int(name[3]) if (len(name) > 3 and name[3].isdigit()) else 0
    if "gain" in name:
        mask = ((idx[:, None] < icp) & (idx[None, :] >= icp)).astype(np.float64)
    else:
        mask = ((idx[:, None] <= icp) & (idx[None, :] > icp)).astype(np.float64)
    mask = mask + mask.T
    out = (1.0 - mask) + mask * eps
    np.fill_diagonal(out, 1.0)
    return out


def is_definitive(name: str) -> bool:
    """True if the change type implies a topographic (irreversible) change."""
    return name in ("DYN1_gain", "DYN2_gain", "DYN3_gain") or "loss" in name


def change_index(name: str, n: int) -> int:
    """Acquisition index i_cp after which the change occurs (Sec. IV-A)."""
    if name == "ADCS":
        return 2
    if len(name) > 3 and name[3].isdigit():
        return int(name[3])
    return 0


# ---------------------------------------------------------------------------
# Coherence matrix assembly
# ---------------------------------------------------------------------------
def build_gamma(change: str, n: int, tau_ratio: int, bn_bc: float,
                gamma0: float = C.GAMMA0) -> np.ndarray:
    """Ideal (true) coherence matrix Gamma of Eq. (5) for a given target.

    Eq. (5) states Gamma = gamma_0 * gamma_t * gamma_b, whose diagonal is
    gamma_0 * gamma_t(0) * gamma_b = gamma_0 < 1.  That matrix is *not* a valid
    coherence matrix (a coherence matrix must have a unit diagonal), so the
    unit diagonal is restored afterwards, exactly as for the "frozen" targets of
    the InSAR literature.  Forcing the diagonal a posteriori makes the matrix
    slightly non positive-definite (the Cholesky factor would no longer
    reproduce it), therefore the matrix is finally rescaled into the closest
    proper correlation matrix: this preserves the *coherence* (i.e. the
    correlation) exactly while making the unit diagonal consistent.
    """
    gt = gamma_temporal(tau_ratio, n)
    gb = gamma_spatial(bn_bc)
    pat = change_pattern(change, n)
    gamma = gamma0 * gb * gt * pat
    np.fill_diagonal(gamma, 1.0)

    # --- make the whole matrix a consistent correlation matrix -------------
    gamma = 0.5 * (gamma + gamma.T)
    w, Q = np.linalg.eigh(gamma)
    w = np.clip(w, 1e-12, None)          # project onto the PSD cone
    gamma = (Q * w) @ Q.T
    gamma = 0.5 * (gamma + gamma.T)
    d = np.sqrt(np.clip(np.diag(gamma), 1e-12, None))
    gamma = gamma / np.outer(d, d)       # exact unit diagonal, coherence kept
    np.fill_diagonal(gamma, 1.0)
    return np.clip(gamma, 0.0, 1.0)


def cholesky_upper(gamma: np.ndarray) -> np.ndarray:
    """Upper-triangular ``V`` such that ``V.T @ V = gamma`` (Eq. (21))."""
    try:
        return np.linalg.cholesky(gamma).T
    except np.linalg.LinAlgError:
        g = 0.5 * (gamma + gamma.T)
        w, Q = np.linalg.eigh(g)
        w = np.clip(w, 1e-10, None)
        g = (Q * w) @ Q.T
        d = np.sqrt(np.clip(np.diag(g), 1e-12, None))
        g = g / np.outer(d, d)
        np.fill_diagonal(g, 1.0)
        return np.linalg.cholesky(g + np.eye(g.shape[0]) * 1e-12).T


def cholesky_unit_intensity(gamma: np.ndarray) -> np.ndarray:
    """Return the lower Cholesky factor used by ``S = L d``.

    The coherence matrices assembled here have unit diagonal.  Therefore the
    rows of ``L = chol(gamma)`` already have unit squared norm and the white
    complex process with ``E|d|^2=1`` has both the requested intensity and
    coherence.  Returning the lower factor avoids the former upper/lower
    transpose mismatch (the paper writes the equivalent operation as
    ``S=V' d`` with ``V'V=Gamma``).
    """
    g = 0.5 * (np.asarray(gamma, dtype=np.float64) + np.asarray(gamma, dtype=np.float64).T)
    try:
        L = np.linalg.cholesky(g)
    except np.linalg.LinAlgError:
        w, Q = np.linalg.eigh(g)
        w = np.clip(w, 1e-10, None)
        g = (Q * w) @ Q.T
        g = 0.5 * (g + g.T)
        d0 = np.sqrt(np.clip(np.diag(g), 1e-12, None))
        g = g / np.outer(d0, d0)
        np.fill_diagonal(g, 1.0)
        L = np.linalg.cholesky(g + np.eye(g.shape[0]) * 1e-12)
    row_norm = np.sqrt(np.maximum((L ** 2).sum(axis=1), EPS))
    return L / row_norm[:, None]


def cholesky_per_pixel(gamma_tile: np.ndarray, pat_mask: np.ndarray,
                       eps: float = C.EPSILON_LOW) -> np.ndarray:
    """Cholesky factors of the *effective* coherence matrix of each pixel.

    Parameters
    ----------
    gamma_tile : [n, n]  gamma_0 * gamma_b * gamma_t of the pilot tile
        (gamma_t of Eq. (5) - the same for all the pixels of the tile)
    pat_mask   : [M, n, n] change-pattern mask, 1 = same radar object,
        eps = different radar object (Eq. (9), (15))

    Returns
    -------
    V : [M, n, n] with V[m].T @ V[m] = Gamma_m, and E|S_i|^2 = 1 for every m.

    Because the masked matrix is not a valid correlation matrix (the block
    structure of Eq. (13) forces a diagonal equal to gamma_0 * eps), the
    Cholesky factor is rescaled row-wise so that the radar-brightness
    calibration of Eq. (27) holds exactly while the effective coherence
    (V V^T)_ij / (||V_i|| ||V_j||) of the two radar objects is preserved.
    """
    M, n, _ = pat_mask.shape
    out = np.empty((M, n, n), dtype=np.float64)
    for m in range(M):
        g = gamma_tile * pat_mask[m]
        np.fill_diagonal(g, 1.0)
        g = 0.5 * (g + g.T)
        V = np.linalg.cholesky(g + np.eye(n) * 1e-12)
        d = np.sqrt(np.maximum((V ** 2).sum(axis=1), EPS))
        out[m] = V / d[:, None]
    return out
