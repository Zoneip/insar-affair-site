"""Figures and tables of the DANI-NET reproduction (Figs. 6, 11, 12, 14; Table III).

Usage:
    python -m daninet.plot dataset            # dataset statistics (Fig. 11)
    python -m daninet.plot example            # synthetic patch   (Fig. 6)
    python -m daninet.plot report             # tables + confusion matrices
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import matplotlib                            # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt              # noqa: E402

from daninet import config as C              # noqa: E402
from daninet import patterns as PAT          # noqa: E402
from daninet import synthetic as SYN         # noqa: E402

OUT = C.OUT_DIR
CLASS_NAMES = ["Class 0 (AC/NC)", "Class 1 (DYN-1)", "Class 2 (DYN-2)",
               "Class 3 (DYN-3/ADCS)"]
TYP_NAMES = ["AC", "NC", "TC", "DC", "ADCS"]
COH_PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]


# ---------------------------------------------------------------------------
# Fig. 11 - dataset statistics
# ---------------------------------------------------------------------------
def dataset_statistics(n_patches: int = 64, L_values=None, seed: int = 7):
    cfg = C.default_cfg()
    rng = np.random.default_rng(seed)
    table = SYN.CoherenceTable(cfg)
    counts_c = np.zeros(C.N_CLASSES, dtype=np.int64)
    counts_t = np.zeros(5, dtype=np.int64)
    ch = np.zeros(2, dtype=np.int64)          # changed / unchanged pixels
    for _ in range(n_patches // 8):
        x, y, icp, typ = SYN.build_patch_batch(8, cfg, rng, table, L_values=L_values)
        counts_c += np.bincount(y.ravel(), minlength=C.N_CLASSES)
        counts_t += np.bincount(typ.ravel(), minlength=5)
        ch[0] += int((y > 0).sum())
        ch[1] += int((y == 0).sum())
    tot = counts_c.sum()
    fig, ax = plt.subplots(1, 3, figsize=(13, 3.6))
    ax[0].bar(["changed", "unchanged"], [ch[0], ch[1]],
              color=["#c0392b", "#2c7fb8"])
    ax[0].set_title("change / no change")
    ax[1].bar(CLASS_NAMES, counts_c, color="#34495e")
    ax[1].set_title("classes of change")
    ax[1].tick_params(axis='x', rotation=25)
    ax[2].bar(TYP_NAMES, counts_t, color="#16a085")
    ax[2].set_title("target typology")
    for a in ax:
        a.grid(alpha=.3, axis='y')
    fig.suptitle("Synthetic dataset statistics - %d patches (%.1f M pixels)"
                 % (n_patches, tot / 1e6))
    fig.tight_layout()
    p = os.path.join(OUT, "dataset_statistics.png")
    fig.savefig(p, dpi=130)
    plt.close(fig)
    mx = counts_c / tot
    print(f"  class fractions : {np.round(mx, 4)}")
    print(f"  typology counts : {dict(zip(TYP_NAMES, counts_t.tolist()))}")
    print(f"  changed/unchanged = {ch[0] / ch[1]:.3f}")
    print(f"  -> {p}")
    return p


# ---------------------------------------------------------------------------
# Fig. 6 - one synthetic patch
# ---------------------------------------------------------------------------
def example_patch(L_value: int = 121, cls: int = 2, seed: int = 11):
    cfg = C.default_cfg()
    rng = np.random.default_rng(seed)
    table = SYN.CoherenceTable(cfg)
    x, y, icp, typ = SYN.build_patch_batch(8, cfg, rng, table, L_values=[L_value])
    b = int(np.argmax((y == cls).sum(axis=(1, 2))))
    Bw = cfg.physics.Bw
    fig, ax = plt.subplots(3, 4, figsize=(12.5, 9))
    for k in range(4):
        ax[0, k].imshow(x[b, k], cmap="gray")
        ax[0, k].set_title(f"amplitude {k} (normalised)")
        ax[1, k].imshow(x[b, Bw + k] if k < 6 else np.zeros_like(y[b]),
                        cmap="viridis", vmin=0, vmax=1)
        ax[1, k].set_title(f"coherence {COH_PAIRS[k][0]}-{COH_PAIRS[k][1]}"
                           if k < len(COH_PAIRS) else "")
    for k in range(2):
        ax[2, k].imshow(x[b, Bw + 4 + k] if Bw + 4 + k < x.shape[1] else np.zeros_like(y[b]),
                        cmap="viridis", vmin=0, vmax=1)
        ax[2, k].set_title(f"coherence {COH_PAIRS[4 + k][0]}-{COH_PAIRS[4 + k][1]}")
    im = ax[2, 2].imshow(y[b], cmap="tab10", vmin=0, vmax=9)
    ax[2, 2].set_title("reference change map (class)")
    ax[2, 3].imshow(icp[b], cmap="magma")
    ax[2, 3].set_title("change point i_cp")
    for a in ax.ravel():
        a.set_xticks([])
        a.set_yticks([])
    fig.colorbar(im, ax=ax[2, 2], fraction=.046)
    fig.suptitle(f"Example of synthetic patch - L={L_value}, class={cls} "
                 f"(Bw={Bw} amplitude + 6 coherence channels)")
    fig.tight_layout()
    p = os.path.join(OUT, "example_patch.png")
    fig.savefig(p, dpi=130)
    plt.close(fig)
    print(f"  -> {p}")
    return p


# ---------------------------------------------------------------------------
# Table III / Fig. 12 - report from the training runs
# ---------------------------------------------------------------------------
def _load_runs():
    runs = {}
    if not os.path.isdir(C.RUNS_DIR):
        return runs
    for name in sorted(os.listdir(C.RUNS_DIR)):
        f = os.path.join(C.RUNS_DIR, name, "metrics.json")
        if os.path.isfile(f):
            with open(f, encoding="utf-8") as fh:
                report = json.load(fh)
                # Once a corrected run exists, keep stale pre-fix metrics out
                # of the generated summary and comparison figures.
                if report.get("implementation_revision") == "physics_label_fix_v2":
                    runs[name] = report
    if runs:
        return runs
    # Backward-compatible fallback for repositories containing only historical
    # runs created before the revision marker was introduced.
    for name in sorted(os.listdir(C.RUNS_DIR)):
        f = os.path.join(C.RUNS_DIR, name, "metrics.json")
        if os.path.isfile(f):
            with open(f, encoding="utf-8") as fh:
                runs[name] = json.load(fh)
    return runs


def report():
    runs = _load_runs()
    if not runs:
        print("no runs found in", C.RUNS_DIR)
        return
    lines = ["# DANI-NET reproduction - performance summary", ""]
    lines.append("## Trainable parameters")
    lines.append("")
    lines.append("| run | parameters | train L | epochs | best epoch | patches/epoch |")
    lines.append("|---|---|---|---|---|---|")
    for n, r in runs.items():
        lines.append(f"| {n} | {r['n_parameters']} | {r['train_L']} | "
                     f"{r['epochs_run']} | {r['best_epoch']} | "
                     f"{r['train_patches_per_epoch']} |")
    lines.append("")
    lines.append("## Test performance (Table III layout): weighted F1 / ACC")
    lines.append("")
    test_L = sorted({int(k) for r in runs.values() for k in r["tests"]})
    lines.append("| run (train L) | " + " | ".join(f"L={L}" for L in test_L) + " |")
    lines.append("|---" * (len(test_L) + 1) + "|")
    for n, r in runs.items():
        cells = []
        for L in test_L:
            t = r["tests"].get(str(L))
            cells.append(f"{t['f1_weighted']:.3f} / {t['acc']:.3f}" if t else "-")
        lines.append(f"| {n} | " + " | ".join(cells) + " |")
    lines.append("")
    lines.append("## Probability of detection p_D per class (Table VIII layout)")
    lines.append("")
    lines.append("| run | test L | p_D c0 | p_D c1 | p_D c2 | p_D c3 |")
    lines.append("|---|---|---|---|---|---|")
    for n, r in runs.items():
        for L in test_L:
            t = r["tests"].get(str(L))
            if t:
                pd = t["p_d"]
                lines.append(f"| {n} | {L} | " + " | ".join(f"{v:.3f}" for v in pd)
                             + " |")
    txt = "\n".join(lines)
    p = os.path.join(OUT, "summary.md")
    with open(p, "w", encoding="utf-8") as fh:
        fh.write(txt)
    print(txt)
    print(f"\n  -> {p}")

    # confusion matrices (Fig. 12)
    n_runs = len(runs)
    fig, axes = plt.subplots(1, n_runs, figsize=(4.2 * n_runs, 3.8), squeeze=False)
    for j, (n, r) in enumerate(runs.items()):
        L = int(sorted(r["tests"], key=lambda k: int(k))[0])
        cm = np.array(r["tests"][str(L)]["confusion"], dtype=float)
        cmn = cm / np.maximum(cm.sum(axis=1, keepdims=True), 1e-12)
        ax = axes[0][j]
        im = ax.imshow(cmn, vmin=0, vmax=1, cmap="Blues")
        for a in range(cmn.shape[0]):
            for b in range(cmn.shape[1]):
                ax.text(b, a, f"{cmn[a, b]:.2f}", ha="center", va="center",
                        fontsize=8, color="black" if cmn[a, b] < .6 else "white")
        ax.set_xticks(range(4))
        ax.set_yticks(range(4))
        ax.set_xlabel("predicted")
        ax.set_ylabel("true")
        ax.set_title(f"{n}\ntest L={L}")
    fig.suptitle("Confusion matrices (row-normalised) - l.h.s. of Fig. 12")
    fig.tight_layout()
    pc = os.path.join(OUT, "confusion_matrices.png")
    fig.savefig(pc, dpi=130)
    plt.close(fig)
    print(f"  -> {pc}")

    # training curves
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    for n, r in runs.items():
        h = r["history"]
        ep = [d["epoch"] for d in h]
        ax[0].plot(ep, [d["val_loss"] for d in h], marker="o", ms=3, label=n)
        ax[1].plot(ep, [d["val_f1_weighted"] for d in h], marker="o", ms=3, label=n)
    ax[0].set_xlabel("epoch")
    ax[0].set_ylabel("validation CCE loss")
    ax[1].set_xlabel("epoch")
    ax[1].set_ylabel("validation F1_w")
    for a in ax:
        a.grid(alpha=.3)
        a.legend(fontsize=8)
    fig.suptitle("Training curves")
    fig.tight_layout()
    pt = os.path.join(OUT, "training_curves.png")
    fig.savefig(pt, dpi=130)
    plt.close(fig)
    print(f"  -> {pt}")

    # example prediction maps from the first run that saved them
    for n, r in runs.items():
        f = os.path.join(C.RUNS_DIR, n, "examples.npz")
        if os.path.isfile(f):
            d = np.load(f)
            fig, ax = plt.subplots(2, 3, figsize=(11, 7))
            ax[0, 0].imshow(d["amplitude"][0], cmap="gray")
            ax[0, 0].set_title("amplitude epoch 0")
            ax[0, 1].imshow(d["amplitude"][-1], cmap="gray")
            ax[0, 1].set_title(f"amplitude epoch {d['amplitude'].shape[0] - 1}")
            ax[0, 2].imshow(d["coherence"][0], cmap="viridis", vmin=0, vmax=1)
            ax[0, 2].set_title("coherence 0-1")
            ax[1, 0].imshow(d["reference"], cmap="tab10", vmin=0, vmax=9)
            ax[1, 0].set_title("reference")
            ax[1, 1].imshow(d["prediction"], cmap="tab10", vmin=0, vmax=9)
            ax[1, 1].set_title("DANI-NET prediction")
            err = (d["reference"] != d["prediction"]).astype(float)
            ax[1, 2].imshow(err, cmap="Reds", vmin=0, vmax=1)
            ax[1, 2].set_title(f"errors ({(err.mean() * 100):.2f} % pixels)")
            for a in ax.ravel():
                a.set_xticks([])
                a.set_yticks([])
            fig.suptitle(f"Prediction example - run {n}")
            fig.tight_layout()
            pe = os.path.join(OUT, "prediction_example.png")
            fig.savefig(pe, dpi=130)
            plt.close(fig)
            print(f"  -> {pe}")
            break


if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else "report"
    os.makedirs(OUT, exist_ok=True)
    if what == "dataset":
        dataset_statistics()
    elif what == "example":
        example_patch()
    elif what == "report":
        report()
    else:
        print(__doc__)
