"""DANI-NET architecture (Sec. V-A, Fig. 7, Table IV).

Fully-convolutional network, no pooling: the geometric resolution is preserved
at every layer.  The input is the Amplitude-Coherence tensor of Fig. 2
(Bw amplitude samples + Bw(Bw-1)/2 coherences) and the output is the pixel-wise
spatio-temporal change map over the four classes of Sec. IV-A.

    input block  : two 1x1 convolutions mixing the input channels up to 128
                   feature maps, each followed by batch norm and ReLU
    hidden blocks: `n_blocks` 3x3 convolutions with 128 feature maps, each
                   followed by batch norm and ReLU (no pooling)
    output block : 1x1 convolution + batch norm + dropout, then a 1x1
                   convolution down to the number of classes and softmax
"""
from __future__ import annotations

from typing import List

import torch
import torch.nn as nn

from ..config import NetCfg


class DANINet(nn.Module):
    def __init__(self, cfg: NetCfg | None = None):
        super().__init__()
        self.cfg = cfg or NetCfg()
        c_in = self.cfg.in_channels
        c_hid = self.cfg.hidden_channels
        n_cls = self.cfg.n_classes

        # ---- input block: mix the input channels up to c_hid feature maps
        self.stem = nn.Sequential(
            nn.Conv2d(c_in, self.cfg.stem_channels, kernel_size=1),
            nn.BatchNorm2d(self.cfg.stem_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(self.cfg.stem_channels, c_hid, kernel_size=1),
            nn.BatchNorm2d(c_hid),
            nn.ReLU(inplace=True),
        )
        # ---- hidden blocks: full-resolution 3x3 convolutions
        blocks: List[nn.Module] = []
        for _ in range(self.cfg.n_hidden_blocks):
            blocks += [
                nn.Conv2d(c_hid, c_hid, kernel_size=3, padding=1),
                nn.BatchNorm2d(c_hid),
                nn.ReLU(inplace=True),
            ]
        self.hidden = nn.Sequential(*blocks)
        # ---- output block
        self.head = nn.Sequential(
            nn.Conv2d(c_hid, c_hid, kernel_size=1),
            nn.BatchNorm2d(c_hid),
            nn.Dropout2d(self.cfg.dropout),
            nn.Conv2d(c_hid, n_cls, kernel_size=1),
        )
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x: torch.Tensor, return_logits: bool = False):
        h = self.stem(x)
        h = self.hidden(h)
        logits = self.head(h)
        probs = self.softmax(logits)
        if return_logits:
            return probs, logits
        return probs

    # -- diagnostics -------------------------------------------------------
    @staticmethod
    def n_parameters(model: nn.Module) -> int:
        return sum(p.numel() for p in model.parameters() if p.requires_grad)


def build_model(cfg: NetCfg | None = None) -> DANINet:
    return DANINet(cfg)


# ---------------------------------------------------------------------------
# Table IV cross-check
# ---------------------------------------------------------------------------
# Trainable parameters published in Table IV of the paper.
TABLE_IV = {5: 759044, 10: 1496452, 15: 2235652, 20: 2974852, 25: 3714052}


def parameter_table(n_blocks=(5, 10, 15, 20, 25)) -> List[dict]:
    """Trainable parameters of DANI-NET as a function of its depth (Table IV)."""
    rows = []
    for n in n_blocks:
        cfg = NetCfg(n_hidden_blocks=int(n))
        m = DANINet(cfg)
        n_par = DANINet.n_parameters(m)
        ref = TABLE_IV.get(int(n))
        rows.append(dict(n_hidden_blocks=int(n), parameters=n_par, table_iv=ref,
                         delta=None if ref is None else n_par - ref))
    return rows


if __name__ == "__main__":
    print(f"{'depth':>6} {'ours':>12} {'Table IV':>12} {'delta':>8}")
    prev = None
    for r in parameter_table():
        inc = "" if prev is None else f"   (+{r['parameters'] - prev} per 5 blocks)"
        print(f"{r['n_hidden_blocks']:>6} {r['parameters']:>12} "
              f"{r['table_iv'] if r['table_iv'] else '-':>12} "
              f"{r['delta'] if r['delta'] is not None else '-':>8}{inc}")
        prev = r["parameters"]
