"""Performance metrics for the multi-class change map (Sec. V-C).

Everything is derived from the confusion matrix, as in the paper:
    ACC  = (TP + TN) / (TN + FP + TP + FN)                    Eq. (36)
    F1   = 2 TP / (2 TP + FP + FN)                            Eq. (37)
    F1_w = sum_c w_c F1(c),  w_c = fraction of true instances  Eq. (38)
    p_D  = diagonal of the row-normalised confusion matrix
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np

N_CLASSES = 4


def confusion(y_true: np.ndarray, y_pred: np.ndarray,
              n_classes: int = N_CLASSES) -> np.ndarray:
    """Confusion matrix [n_classes, n_classes]; rows = true, cols = predicted."""
    idx = y_true.astype(np.int64) * n_classes + y_pred.astype(np.int64)
    return np.bincount(idx.ravel(), minlength=n_classes ** 2).reshape(n_classes,
                                                                     n_classes)


def metrics_from_confusion(cm: np.ndarray) -> Dict[str, object]:
    """ACC, F1 per class, macro F1, weighted F1 and probability of detection."""
    cm = cm.astype(np.float64)
    total = cm.sum()
    acc = float(np.trace(cm) / total) if total else 0.0
    tp = np.diag(cm)
    fp = cm.sum(axis=0) - tp
    fn = cm.sum(axis=1) - tp
    with np.errstate(invalid='ignore', divide='ignore'):
        f1 = np.where((2 * tp + fp + fn) > 0, 2 * tp / (2 * tp + fp + fn), 0.0)
    support = cm.sum(axis=1)
    w = support / support.sum() if support.sum() else np.zeros_like(support)
    f1_w = float((w * f1).sum())
    f1_macro = float(f1.mean())
    with np.errstate(invalid='ignore', divide='ignore'):
        p_d = np.where(support > 0, tp / np.maximum(support, 1e-12), 0.0)
    return dict(acc=acc, f1=f1.tolist(), f1_macro=f1_macro, f1_weighted=f1_w,
                p_d=p_d.tolist(), support=support.astype(np.int64).tolist(),
                confusion=cm.astype(np.int64).tolist())


def detection_probs(cm: np.ndarray) -> List[float]:
    """p_D of each class = P(predicted = c | true = c)."""
    return metrics_from_confusion(cm)["p_d"]


def format_report(m: Dict[str, object], title: str = "") -> str:
    lines = []
    if title:
        lines.append(title)
    lines.append(f"  ACC = {m['acc']:.4f}   F1_w = {m['f1_weighted']:.4f}   "
                 f"F1_macro = {m['f1_macro']:.4f}")
    lines.append("  per class:  " + "  ".join(
        f"c{c}: F1={m['f1'][c]:.3f} p_D={m['p_d'][c]:.3f} n={m['support'][c]}"
        for c in range(len(m["f1"]))))
    cm = np.array(m["confusion"])
    lines.append("  confusion matrix (rows true, cols predicted):")
    for r in range(cm.shape[0]):
        lines.append("    " + "  ".join(f"{v:8d}" for v in cm[r]))
    return "\n".join(lines)
