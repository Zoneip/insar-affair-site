"""Training and evaluation of DANI-NET (Sec. V-B, V-D, VII).

Training strategy of the paper:
  * inputs normalised between 0 and 1 (Sec. V-B);
  * Categorical Cross-Entropy loss (Eq. (34)) and Adam optimiser;
  * learning rate schedule of Eq. (35):
        1e-4 for 1 <= epoch <= 14,  1e-5 for 14 < epoch <= 24,  1e-6 afterwards;
  * training stopped when the validation loss does not improve for 16 epochs;
  * two purposes: the *baseline* assessment (one number of looks per training
    run) and the *final* model trained over the augmented dataset that mixes
    all the numbers of looks.

The synthetic patches are generated on the fly by a pool of worker processes
(the generator is CPU bound) and consumed by the GPU training loop, so that
data generation and optimisation overlap.
"""
from __future__ import annotations

import contextlib
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from collections import deque
from dataclasses import asdict
from typing import Iterator, List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(os.path.dirname(_HERE))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from daninet import config as C          # noqa: E402
from daninet import synthetic as SYN     # noqa: E402
from daninet.net import metrics as M     # noqa: E402
from daninet.net.model import DANINet    # noqa: E402


# ---------------------------------------------------------------------------
# device selection (CPU / CUDA / Ascend NPU)
# ---------------------------------------------------------------------------
def _load_torch_npu():
    """Import torch_npu on demand; returns the module or None."""
    try:
        import torch_npu  # noqa: F401
        return torch_npu
    except Exception:
        return None


def resolve_device(pref: Optional[str] = "auto") -> torch.device:
    """Resolve the training device.

    ``auto`` prefers Ascend NPU, then CUDA, then CPU.  An explicit ``npu``
    request fails loudly rather than silently falling back, because a silent
    fallback would produce results on the wrong hardware.
    """
    pref = (pref or "auto").lower()
    if pref == "auto":
        if _load_torch_npu() is not None and torch.npu.is_available():
            return torch.device("npu")
        if torch.cuda.is_available():
            return torch.device("cuda")
        return torch.device("cpu")
    if pref == "npu":
        if _load_torch_npu() is None:
            raise SystemExit("--device npu 但无法 import torch_npu（检查 CANN 环境是否已 source set_env.sh）")
        if not torch.npu.is_available():
            raise SystemExit("--device npu 但 torch.npu.is_available() 为 False")
    if pref == "cuda" and not torch.cuda.is_available():
        raise SystemExit("--device cuda 但 CUDA 不可用")
    return torch.device(pref)


@contextlib.contextmanager
def autocast_ctx(device: torch.device, enabled: bool):
    """Autocast on the accelerators that have been verified (CUDA / Ascend NPU)."""
    if enabled and device.type in ("cuda", "npu"):
        with torch.amp.autocast(device.type):
            yield
    else:
        yield


def resolve_amp(pref: str, device: torch.device) -> bool:
    """``auto`` enables fp16 on accelerators and keeps CPU in fp32."""
    pref = (pref or "auto").lower()
    if pref == "off":
        return False
    if pref == "on":
        if device.type == "cpu":
            raise SystemExit("--amp on 但设备是 CPU；混合精度只支持 cuda/npu")
        return True
    return device.type in ("cuda", "npu")


def device_banner(device: torch.device) -> str:
    parts = [f"device={device}"]
    parts.append(f"torch={torch.__version__}")
    if device.type == "npu":
        npu = _load_torch_npu()
        parts.append(f"torch_npu={getattr(npu, '__version__', '?')}")
        parts.append(f"npu_count={torch.npu.device_count()}")
        parts.append(f"npu_name={torch.npu.get_device_name(device)}")
    elif device.type == "cuda":
        parts.append(f"gpu={torch.cuda.get_device_name(device)}")
    return "  ".join(parts)


# ---------------------------------------------------------------------------
# worker side: generate one batch of patches
# ---------------------------------------------------------------------------
_W: dict = {}


def _worker_init(cfg: C.Cfg, root: str, transport: str = "fp32"):
    if root not in sys.path:
        sys.path.insert(0, root)
    _W["cfg"] = cfg
    _W["table"] = SYN.CoherenceTable(cfg)
    _W["transport"] = transport


def _gen_batch(task: Tuple[int, int, Optional[Tuple[int, ...]], bool]):
    seed, bs, L_values, change_only = task
    rng = np.random.default_rng(seed)
    x, y, icp, typ = SYN.build_patch_batch(bs, _W["cfg"], rng, _W["table"],
                                           L_values=L_values, change_only=change_only)
    # The worker->parent pipe carries ~0.65 MB per patch in fp32 and is the
    # measured bottleneck on Ascend (device compute is faster than the pipe).
    # Halving the payload with fp16 doubles the achievable feed rate; the
    # tensor is cast back to fp32 on the device, which costs O(0.1 ms).
    if _W.get("transport") == "fp16":
        x = x.astype(np.float16)
    return x, y, icp, typ


class PatchFeeder:
    """Deterministic, parallel stream of synthetic patches.

    Batch ``k`` is always generated from ``seed0 + k`` so that a given run is
    exactly reproducible (and the validation set identical at every epoch)
    regardless of the number of workers.
    """

    def __init__(self, cfg: C.Cfg, batch_size: int, L_values=None,
                 workers: int = 6, prefetch: int = 8, root: str = _ROOT,
                 change_only: bool = False, change_only_probability: float = 0.0,
                 transport: str = "fp32"):
        self.cfg = cfg
        self.bs = batch_size
        self.L_values = None if L_values is None else tuple(int(v) for v in L_values)
        self.change_only = bool(change_only)
        self.change_only_probability = float(np.clip(change_only_probability, 0.0, 1.0))
        self.workers = max(1, int(workers))
        self.prefetch = max(2, int(prefetch))
        self.transport = "fp16" if str(transport).lower() == "fp16" else "fp32"
        self.pool = None
        if self.workers > 1:
            self.pool = ProcessPoolExecutor(
                max_workers=self.workers, initializer=_worker_init,
                initargs=(cfg, root, self.transport))
        else:
            _worker_init(cfg, root, self.transport)

    def close(self):
        if self.pool is not None:
            self.pool.shutdown(wait=False, cancel_futures=True)
            self.pool = None

    def _submit(self, seed: int):
        # Deterministically interleave baseline and change-only batches for
        # the augmented training distribution (paper Sec. VII-B).
        extra_change = ((int(seed) * 1103515245 + 12345) % 10000) < (
            10000 * self.change_only_probability)
        task = (int(seed), self.bs, self.L_values,
                self.change_only or extra_change)
        if self.pool is None:
            class _F:                                   # tiny eager "future"
                def __init__(self, v):
                    self._v = v

                def result(self):
                    return self._v
            return _F(_gen_batch(task))
        return self.pool.submit(_gen_batch, task)

    def batches(self, n_batches: int, seed0: int) -> Iterator[Tuple[np.ndarray, ...]]:
        pending = deque()
        nxt = 0
        for _ in range(min(self.prefetch, n_batches)):
            pending.append(self._submit(seed0 + nxt))
            nxt += 1
        for _ in range(n_batches):
            fut = pending.popleft()
            out = fut.result()
            if nxt < n_batches:
                pending.append(self._submit(seed0 + nxt))
                nxt += 1
            yield out


# ---------------------------------------------------------------------------
# learning-rate schedule (Eq. (35))
# ---------------------------------------------------------------------------
def lr_for_epoch(epoch: int, cfg: C.TrainCfg) -> float:
    """Eq. (35); ``epoch`` is 1-based."""
    lr = cfg.lr
    for limit, value in cfg.lr_drops:
        if epoch > limit:
            lr = value
    return lr


# ---------------------------------------------------------------------------
# evaluation
# ---------------------------------------------------------------------------
@torch.no_grad()
def evaluate(model: nn.Module, feeder: PatchFeeder, n_batches: int, seed0: int,
             device: torch.device, amp: bool = True, collect_maps: bool = False):
    """Return (mean loss, metrics dict, optional example maps)."""
    model.eval()
    cm = np.zeros((C.N_CLASSES, C.N_CLASSES), dtype=np.int64)
    tot_loss, n_tot = 0.0, 0
    examples = []
    for i, (x, y, icp, typ) in enumerate(feeder.batches(n_batches, seed0)):
        xb = torch.from_numpy(x).to(device, non_blocking=True).float()
        yb = torch.from_numpy(y).to(device, non_blocking=True)
        with autocast_ctx(device, amp):
            probs, logits = model(xb, return_logits=True)
            loss = F.cross_entropy(logits, yb)
        pred = probs.argmax(dim=1)
        cm += M.confusion(yb.cpu().numpy(), pred.cpu().numpy(), C.N_CLASSES)
        tot_loss += float(loss.detach()) * xb.shape[0]
        n_tot += xb.shape[0]
        if collect_maps and len(examples) < 3:
            examples.append(dict(amplitude=x[0, :4].copy(), coherence=x[0, 4:].copy(),
                                 reference=y[0].copy(), prediction=pred[0].cpu().numpy(),
                                 icp=icp[0].copy(), typology=typ[0].copy()))
    model.train()
    return tot_loss / max(n_tot, 1), M.metrics_from_confusion(cm), examples


# ---------------------------------------------------------------------------
# training
# ---------------------------------------------------------------------------
def train(cfg: C.Cfg, run_name: str, L_train: Sequence[int], L_test: Sequence[int],
          n_train_patches: int, n_val_patches: int, n_test_patches: int,
          epochs: int, batch_size: int, workers: int = 6, amp="auto",
          seed: int = 0, device: Optional[str] = None, log=None,
          transport: str = "fp32", prefetch: int = 16,
          weight_decay: float = 0.0) -> dict:
    """Train DANI-NET and assess it over the requested test sets."""
    torch.manual_seed(seed)
    np.random.seed(seed)
    device = resolve_device(device)
    if isinstance(amp, bool):                 # backwards compatible call sites
        amp = "auto" if amp else "off"
    amp = resolve_amp(amp, device)
    run_dir = os.path.join(C.RUNS_DIR, run_name)
    os.makedirs(run_dir, exist_ok=True)

    if log is None:
        log_path = os.path.join(run_dir, "log.txt")
        handle = open(log_path, "a", encoding="utf-8")

        def log(msg, _h=handle):
            line = str(msg)
            print(line, flush=True)
            _h.write(line + "\n")
            _h.flush()

    model = DANINet(cfg.net).to(device)
    n_par = DANINet.n_parameters(model)
    n_train_batches = max(1, int(round(n_train_patches / batch_size)))
    n_val_batches = max(1, int(round(n_val_patches / batch_size)))
    n_test_batches = max(1, int(round(n_test_patches / batch_size)))

    log(f"[{run_name}] {device_banner(device)}  amp={amp}  transport={transport}"
        f"  prefetch={prefetch}  wd={weight_decay}")
    log(f"[{run_name}] patches/epoch={n_train_batches * batch_size}  "
        f"trainable parameters={n_par}")
    log(f"[{run_name}] train L={list(L_train)}   test L={list(L_test)}   "
        f"epochs={epochs}   batch={batch_size}   workers={workers}")

    opt = torch.optim.Adam(model.parameters(), lr=cfg.train.lr,
                           weight_decay=weight_decay)
    scaler_backend = device.type if device.type in ("cuda", "npu") else "cuda"
    scaler = torch.amp.GradScaler(scaler_backend, enabled=amp)

    # deterministic, distinct seed blocks for train / validation / test
    TRAIN_SEED, VAL_SEED, TEST_SEED = 10_000_000, 20_000_000, 30_000_000
    augmented = len(tuple(L_train)) > 1
    feeder = PatchFeeder(cfg, batch_size, L_values=L_train, workers=workers,
                         prefetch=prefetch, transport=transport,
                         change_only_probability=0.5 if augmented else 0.0)
    # Validation follows the training distribution.  The unseen look values
    # (25, 49) belong only to the independent test set in Sec. V-D.
    val_feeder = PatchFeeder(cfg, batch_size, L_values=L_train,
                             workers=max(1, workers // 2), prefetch=prefetch,
                             transport=transport,
                             change_only_probability=0.5 if augmented else 0.0)

    history: List[dict] = []
    best_val = float('inf')
    best_epoch = -1
    bad_epochs = 0
    t_start = time.time()
    model.train()

    for epoch in range(1, epochs + 1):
        lr = lr_for_epoch(epoch, cfg.train)
        for g in opt.param_groups:
            g['lr'] = lr
        run_loss, n_seen = 0.0, 0
        t_ep = time.time()
        for step, (x, y, icp, typ) in enumerate(
                feeder.batches(n_train_batches, TRAIN_SEED + epoch * 1_000_000)):
            xb = torch.from_numpy(x).to(device, non_blocking=True).float()
            yb = torch.from_numpy(y).to(device, non_blocking=True)
            opt.zero_grad(set_to_none=True)
            with autocast_ctx(device, amp):
                _, logits = model(xb, return_logits=True)
                loss = F.cross_entropy(logits, yb)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            run_loss += float(loss.detach()) * xb.shape[0]
            n_seen += xb.shape[0]
            if cfg.train.log_every and (step + 1) % cfg.train.log_every == 0:
                log(f"  [{run_name}] epoch {epoch} step {step + 1}/{n_train_batches}"
                    f"  loss={run_loss / n_seen:.4f}  lr={lr:g}"
                    f"  {n_seen / (time.time() - t_ep):.1f} patches/s")
        train_loss = run_loss / max(n_seen, 1)
        val_loss, val_m, _ = evaluate(model, val_feeder, n_val_batches, VAL_SEED,
                                      device, amp)
        history.append(dict(epoch=epoch, lr=lr, train_loss=train_loss,
                            val_loss=val_loss, val_acc=val_m['acc'],
                            val_f1_weighted=val_m['f1_weighted'],
                            val_p_d=val_m['p_d'],
                            seconds=time.time() - t_ep))
        log(f"  [{run_name}] epoch {epoch}/{epochs}  train_loss={train_loss:.4f}"
            f"  val_loss={val_loss:.4f}  val_F1w={val_m['f1_weighted']:.4f}"
            f"  val_ACC={val_m['acc']:.4f}  ({time.time() - t_ep:.0f} s)")
        if val_loss < best_val - 1e-6:
            best_val, best_epoch, bad_epochs = val_loss, epoch, 0
            torch.save(dict(model=model.state_dict(), cfg=asdict(cfg), epoch=epoch,
                            val_loss=val_loss, n_parameters=n_par),
                       os.path.join(run_dir, "best.pt"))
        else:
            bad_epochs += 1
            if bad_epochs >= cfg.train.early_stop_patience:
                log(f"  [{run_name}] early stop at epoch {epoch} "
                    f"(no improvement for {bad_epochs} epochs)")
                break

    feeder.close()
    total_time = time.time() - t_start

    # ---- final assessment with the best model ----------------------------
    # map to CPU first: checkpoints may have been written on a different backend
    ck = torch.load(os.path.join(run_dir, "best.pt"), map_location="cpu",
                    weights_only=False)
    model.load_state_dict(ck["model"])
    log(f"[{run_name}] best epoch {ck['epoch']} (val_loss={ck['val_loss']:.4f})")

    report = dict(run=run_name, implementation_revision="physics_label_fix_v2",
                  n_parameters=n_par, epochs_run=len(history),
                  best_epoch=int(ck["epoch"]), best_val_loss=float(ck["val_loss"]),
                  train_patches=n_train_batches * batch_size,
                  train_patches_per_epoch=n_train_batches * batch_size,
                  train_L=list(L_train), test_L=list(L_test),
                  history=history, seconds=total_time)
    # test on every requested number of looks (Table III layout)
    tests = {}
    for Lv in L_test:
        f = PatchFeeder(cfg, batch_size, L_values=[Lv], workers=max(1, workers // 2),
                        prefetch=prefetch, transport=transport)
        t_loss, m, ex = evaluate(model, f, n_test_batches, TEST_SEED + int(Lv),
                                 device, amp, collect_maps=(Lv == L_test[0]))
        f.close()
        tests[str(Lv)] = dict(loss=t_loss, **m)
        log(f"[{run_name}] TEST L={Lv}: " + M.format_report(m).replace("\n", "\n  "))
        if ex:
            np.savez_compressed(os.path.join(run_dir, "examples.npz"), **ex[0])
    report["tests"] = tests

    with open(os.path.join(run_dir, "metrics.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    log(f"[{run_name}] done in {total_time / 60:.1f} min -> {run_dir}")
    return report


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main(argv=None):
    import argparse
    p = argparse.ArgumentParser(description="Train DANI-NET on synthetic data")
    p.add_argument("--mode", choices=["baseline", "augmented"], default="baseline",
                   help="baseline: one number of looks per run; augmented: L=ALL")
    p.add_argument("--L", type=int, default=9, help="training L (baseline mode)")
    p.add_argument("--test-L", type=int, nargs="*", default=None,
                   help="numbers of looks used for the final test")
    p.add_argument("--patches", type=int, default=40000,
                   help="training patches per epoch")
    p.add_argument("--val-patches", type=int, default=4000)
    p.add_argument("--test-patches", type=int, default=4000)
    p.add_argument("--epochs", type=int, default=25)
    p.add_argument("--blocks", type=int, default=5, help="hidden blocks (Table IV)")
    p.add_argument("--batch", type=int, default=8)
    p.add_argument("--workers", type=int, default=6)
    p.add_argument("--amp", default="auto", choices=["auto", "on", "off"],
                   help="auto: fp16 on cuda/npu, fp32 on cpu")
    p.add_argument("--no-amp", action="store_true",
                   help="deprecated alias of --amp off")
    p.add_argument("--device", default="auto",
                   choices=["auto", "npu", "cuda", "cpu"],
                   help="auto: npu > cuda > cpu")
    p.add_argument("--transport", default="fp32", choices=["fp32", "fp16"],
                   help="worker->main payload dtype; fp16 doubles the feed rate")
    p.add_argument("--prefetch", type=int, default=16,
                   help="batches queued ahead of the device")
    p.add_argument("--wd", type=float, default=0.0, help="Adam weight decay")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--name", type=str, default=None)
    p.add_argument("--model", type=str, default="tandem",
                   choices=["tandem", "ulaby"], help="backscatter model")
    args = p.parse_args(argv)

    cfg = C.default_cfg()
    cfg.net.n_hidden_blocks = args.blocks
    cfg.physics.backscatter_model = args.model
    cfg.train.log_every = 20

    if args.mode == "augmented":
        L_train = list(cfg.physics.L_train)                  # all the looks
        name = args.name or f"augmented_b{args.blocks}_e{args.epochs}"
    else:
        L_train = [args.L]
        name = args.name or f"baseline_L{args.L}_b{args.blocks}_e{args.epochs}"
    L_test = args.test_L if args.test_L else list(cfg.physics.L_test)

    train(cfg, name, L_train, L_test, args.patches, args.val_patches,
          args.test_patches, args.epochs, args.batch, workers=args.workers,
          amp="off" if args.no_amp else args.amp, seed=args.seed,
          device=args.device, transport=args.transport,
          prefetch=args.prefetch, weight_decay=args.wd)


if __name__ == "__main__":
    main()
