"""Spatio-temporal change patterns (Sec. IV-B, Fig. 5).

A "pile of material" with constant slope variation delta_alpha enters the
illuminated area as a cone (quarter disc) or a pyramid (triangle-like) from one
corner or one side of the patch, growing in time.  Different flips model the
different acquisition geometries (ascending/descending - Fig. 5b/5c).
"""
from __future__ import annotations

from typing import Tuple

import numpy as np

PATTERNS = ("pyramid", "cone")
ENTRY = ("corner", "side")


def _coords(n: int) -> Tuple[np.ndarray, np.ndarray]:
    y, x = np.mgrid[0:n, 0:n].astype(np.float64)
    return y, x


def shape_mask(n: int, pattern: str, cx: float, cy: float, r: float) -> np.ndarray:
    """Binary mask of a cone / pyramid whose vertex is at (cx, cy).

    * cone    : quarter disc of radius r (apex at the vertex)
    * pyramid : isosceles triangle of height r and half-base r (apex at vertex)
    """
    y, x = _coords(n)
    dx = x - cx
    dy = y - cy
    if pattern == "cone":
        d = np.sqrt(dx ** 2 + dy ** 2)
        return (d <= r).astype(np.float64)
    if pattern == "pyramid":
        # triangle pointing towards the patch centre, i.e. growing along +x
        return ((dx >= 0) & (dx <= r) & (np.abs(dy) <= 0.5 * r * (1.0 - dx / max(r, 1e-6)))).astype(np.float64)
    raise ValueError(pattern)


def _apply_flip(mask: np.ndarray, flip: int) -> np.ndarray:
    if flip & 1:
        mask = mask[:, ::-1]
    if flip & 2:
        mask = mask[::-1, :]
    return np.ascontiguousarray(mask)


def _shift_zero(mask: np.ndarray, shift_y: int, shift_x: int) -> np.ndarray:
    """Translate a pattern and crop what leaves the illuminated patch."""
    out = np.zeros_like(mask)
    n, m = mask.shape
    sy0, sy1 = max(0, shift_y), min(n, n + shift_y)
    sx0, sx1 = max(0, shift_x), min(m, m + shift_x)
    src_y0, src_y1 = max(0, -shift_y), max(0, -shift_y) + max(0, sy1 - sy0)
    src_x0, src_x1 = max(0, -shift_x), max(0, -shift_x) + max(0, sx1 - sx0)
    if sy1 > sy0 and sx1 > sx0:
        out[sy0:sy1, sx0:sx1] = mask[src_y0:src_y1, src_x0:src_x1]
    return out


def spatial_pattern(n: int, pattern: str, entry: str, flip: int, r: float,
                    rng: np.random.Generator) -> np.ndarray:
    """One static spatial pattern of dimension n x n (Fig. 5a)."""
    if entry == "corner":
        # grows from a corner towards the opposite one
        pos = rng.integers(0, 4)
        cx = 0.0 if pos in (0, 3) else float(n - 1)
        cy = 0.0 if pos in (0, 1) else float(n - 1)
    else:
        # grows from one side (horizontally or vertically)
        pos = rng.integers(0, 4)
        if pos == 0:
            cx, cy = 0.0, (n - 1) / 2.0
        elif pos == 1:
            cx, cy = float(n - 1), (n - 1) / 2.0
        elif pos == 2:
            cx, cy = (n - 1) / 2.0, 0.0
        else:
            cx, cy = (n - 1) / 2.0, float(n - 1)
    m = shape_mask(n, pattern, cx, cy, r)
    m = _apply_flip(m, flip)
    return m


def temporal_evolution(mask: np.ndarray, icp: int, n_steps: int = 4,
                       rng: np.random.Generator | None = None,
                       oblique: bool = False) -> np.ndarray:
    """Time evolution of a spatial pattern (Figs. 5b/5c).

    Returns an array [n_steps, n, n]; step k is the area affected by the change
    at the k-th epoch.  The shape translates across the patch so that it is
    partially (growing) inside during the epochs and fully inside at the end.
    """
    n = mask.shape[0]
    if rng is None:
        rng = np.random.default_rng(0)
    total = float(icp)
    diag = np.hypot(n, n)
    if oblique:
        ang = rng.uniform(0.0, 2.0 * np.pi)
        vx, vy = np.cos(ang), np.sin(ang)
    else:
        if rng.random() < 0.5:
            vx, vy = 1.0, 0.0
        else:
            vx, vy = 0.0, 1.0
    out = np.zeros((n_steps, n, n), dtype=np.float64)
    # at step icp the pattern has fully entered the patch; before that it is
    # progressively entering from outside the illuminated area.
    for k in range(1, n_steps):
        frac = k / total if total > 0 else 1.0
        frac = float(np.clip(frac, 0.0, 1.0))
        shift_y = int(round(-vy * diag * (1.0 - frac)))
        shift_x = int(round(-vx * diag * (1.0 - frac)))
        out[k] = _shift_zero(mask, shift_y, shift_x)
    out[0] = 0.0
    return out


def change_map_for_class(spatial: np.ndarray, icp: int, name: str) -> np.ndarray:
    """Binary temporal change map [n_steps, n, n] for a given change type."""
    n_steps, n, _ = spatial.shape
    cm = np.zeros_like(spatial)
    if name == "AC":
        return cm
    if name == "NC":
        return np.ones_like(spatial)
    if name == "ADCS":  # appearance only between acquisitions icp and icp+1
        cm[icp] = spatial[icp]
        cm[icp + 1] = spatial[icp + 1]
        return cm
    for k in range(1, n_steps):
        if k > icp:
            cm[k] = spatial[k]
    return cm


def sample_pattern(n: int, icp: int, rng: np.random.Generator) -> Tuple[np.ndarray, str, str, int]:
    """Randomly draw one spatio-temporal pattern of dimension n x n."""
    pattern = PATTERNS[rng.integers(0, len(PATTERNS))]
    entry = ENTRY[rng.integers(0, len(ENTRY))]
    flip = int(rng.integers(0, 4))
    # radius: large enough to cover a significant part of the patch
    r = rng.uniform(0.55 * n, 1.35 * n)
    mask = spatial_pattern(n, pattern, entry, flip, r, rng)
    oblique = (entry == "corner") or (rng.random() < 0.5)
    ev = temporal_evolution(mask, max(icp, 1), 4, rng, oblique=oblique)
    return ev, pattern, entry, flip


# ---------------------------------------------------------------------------
# Vectorised version: draw the patterns of many tiles at once
# ---------------------------------------------------------------------------
_GRID: dict = {}


def _grid(n: int):
    if n not in _GRID:
        y, x = np.mgrid[0:n, 0:n].astype(np.float64)
        _GRID[n] = (y, x)
    return _GRID[n]


def sample_patterns(n_tiles: int, n: int, icp: np.ndarray,
                    rng: np.random.Generator, Bw: int = 4) -> np.ndarray:
    """Draw the spatio-temporal pattern of ``n_tiles`` tiles at once.

    Vectorised counterpart of :func:`sample_pattern`; returns the array
    ``ev`` of dimension [n_tiles, Bw, n, n] where ev[m, k] is the area affected
    by the change at the k-th epoch (Figs. 5a-5c).
    """
    y, x = _grid(n)
    pattern = rng.integers(0, len(PATTERNS), n_tiles)      # 0 pyramid, 1 cone
    entry = rng.integers(0, len(ENTRY), n_tiles)           # 0 corner, 1 side
    pos = rng.integers(0, 4, n_tiles)
    flip = rng.integers(0, 4, n_tiles)
    r = rng.uniform(0.55 * n, 1.35 * n, n_tiles)

    corner = entry == 0
    cx = np.where(corner,
                  np.where((pos == 0) | (pos == 3), 0.0, n - 1.0),
                  np.where(pos == 0, 0.0, np.where(pos == 1, n - 1.0, (n - 1) / 2.0)))
    cy = np.where(corner,
                  np.where((pos == 0) | (pos == 1), 0.0, n - 1.0),
                  np.where(pos == 2, 0.0, np.where(pos == 3, n - 1.0, (n - 1) / 2.0)))
    # inward direction
    dirx = np.where(corner,
                    np.where((pos == 0) | (pos == 3), 1.0, -1.0),
                    np.select([pos == 0, pos == 1], [1.0, -1.0], 0.0))
    diry = np.where(corner,
                    np.where((pos == 0) | (pos == 1), 1.0, -1.0),
                    np.select([pos == 2, pos == 3], [1.0, -1.0], 0.0))
    nrm = np.sqrt(dirx ** 2 + diry ** 2)
    dirx, diry = dirx / nrm, diry / nrm

    dx = x[None] - cx[:, None, None]
    dy = y[None] - cy[:, None, None]
    rr = r[:, None, None]
    u = dirx[:, None, None] * dx + diry[:, None, None] * dy
    v = -diry[:, None, None] * dx + dirx[:, None, None] * dy
    tri = (u >= 0) & (u <= rr) & (np.abs(v) <= 0.5 * rr * (1.0 - u / rr))
    cone = (np.sqrt(dx ** 2 + dy ** 2) <= rr)
    mask = np.where((pattern == 1)[:, None, None], cone, tri).astype(np.float64)

    # flips (Fig. 5b/5c): ascending/descending acquisition geometries
    mask = np.where((flip & 1)[:, None, None] > 0, mask[:, :, ::-1], mask)
    mask = np.where((flip & 2)[:, None, None] > 0, mask[:, ::-1, :], mask)

    # temporal evolution: the shape translates inside the patch
    total = np.maximum(icp, 1).astype(np.float64)
    ang = rng.uniform(0.0, 2.0 * np.pi, n_tiles)
    vx = np.cos(ang)
    vy = np.sin(ang)
    diag = np.hypot(n, n)
    ev = np.zeros((n_tiles, Bw, n, n), dtype=np.float64)
    for k in range(1, Bw):
        for q in range(n_tiles):
            frac = float(np.clip(k / total[q], 0.0, 1.0))
            sy = int(round(-vy[q] * diag * (1.0 - frac)))
            sx = int(round(-vx[q] * diag * (1.0 - frac)))
            ev[q, k] = _shift_zero(mask[q], sy, sx)
    return ev
