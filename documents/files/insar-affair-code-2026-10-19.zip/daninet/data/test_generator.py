"""Self-consistency tests of the synthetic signal model.

Verifies the physics claims of the paper:
  1. the beta0 models of Eq. (17)/(18) are plausible and differ by ~5 dB;
  2. the re-scaling of Eq. (27)-(33) reproduces E[|S|^2] = beta0;
  3. the sample coherence estimator shows the finite-L bias described in Sec. VIII;
  4. the four classes of change produce the "cross" (TC, Eq. (12)) and the
     "block" (DC, Eq. (13)) structures, ADCS an independent island;
  5. the [10 x 128 x 128] patches are well formed and the classes balanced.
"""
from __future__ import annotations

import os
import sys
import time

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(_HERE)))   # project root (E:\DaniNet)

from daninet import config as C          # noqa: E402
from daninet import physics as PH        # noqa: E402
from daninet import synthetic as SYN     # noqa: E402

OK = "[OK]  "
BAD = "[FAIL]"

KIND_CODE = {"AC": 0, "NC": 1, "TC": 2, "DC": 3, "ADCS": 4}


def make_scenario(kind: str, M: int, cfg: C.Cfg, cls: int = 0, icp: int = 0,
                  theta: float = 35.0, theta_l: float = 35.0, bn: float = 0.0,
                  tau: int = 1, L: int = 4000):
    """Build a scenario dict with a single target typology (see synthesise_tile)."""
    Bw = cfg.physics.Bw
    e_mask = np.zeros((M, Bw), dtype=bool)
    definitive = np.zeros(M, dtype=bool)
    if kind == "NC":
        pass
    elif kind == "TC":
        e_mask[:, icp] = True                       # isolated temporary change
    elif kind == "DC":
        e_mask[:, icp:] = True
        definitive[:] = True
    elif kind == "ADCS":
        e_mask[:, icp] = True
        e_mask[:, min(icp + 1, Bw - 1)] = True
    delta_alpha = np.full(M, 5.0 if kind in ("DC", "ADCS") else 0.0)
    return dict(theta=np.full(M, theta), theta_l=np.full(M, theta_l),
                delta_alpha=delta_alpha,
                bn=np.full(M, bn), tau=np.full(M, tau), L=np.full(M, L),
                cls=np.full(M, cls), kind=np.array([kind] * M, dtype=object),
                definitive=definitive, e_mask=e_mask, icp=np.full(M, icp))


def test_backscatter_models():
    print("\n== 1. backscatter models (Eq. (17)/(18), Table I) ==")
    theta = np.deg2rad(np.arange(25, 56, 5.0))
    b_ul = PH.beta0_db(theta, "ulaby")
    b_td = PH.beta0_db(theta, "tandem")
    for t, a, b in zip(np.rad2deg(theta), b_ul, b_td):
        print(f"  theta={t:5.1f} deg   Ulaby={a:7.2f} dB   TanDEM={b:7.2f} dB")
    ok = bool(np.all(np.isfinite(b_ul)) and np.all(np.isfinite(b_td)))
    d = np.abs(b_ul - b_td)
    print(OK if 1.0 < d.mean() < 12.0 else BAD,
          f"mean |Ulaby - TanDEM| = {d.mean():.2f} dB (text reports ~5 dB)")
    return ok


def test_scaling():
    print("\n== 2. radar-brightness re-scaling (Eq. (27)-(33)) ==")
    cfg = C.default_cfg()
    rng = np.random.default_rng(0)
    table = SYN.CoherenceTable(cfg)
    M = 400
    ok = True
    for kind, cls, icp in [("AC", 0, 0), ("DC", 2, 2), ("TC", 2, 2), ("ADCS", 3, 2)]:
        sc = make_scenario(kind, M, cfg, cls=cls, icp=icp, theta_l=42.0)
        ev = np.ones((M, cfg.physics.Bw, 16, 16))
        out = SYN.synthesise_tile(sc, ev, rng, cfg, table)
        b0_lin = np.power(10.0, out["beta0"] / 10.0)
        line = []
        for k in range(cfg.physics.Bw):
            emp = 10 * np.log10(np.mean(np.abs(out["slc"][:, k]) ** 2))
            tgt = 10 * np.log10(b0_lin[:, k].mean())
            line.append(f"e{k}:{emp - tgt:+.2f}")
            if abs(emp - tgt) > 0.5:
                ok = False
        print(f"  {kind:>4} (cls={cls}, icp={icp})  10log10(E|S|^2 / beta0): " + "  ".join(line))
    print(OK if ok else BAD, "E|S|^2 = beta0 within 0.5 dB for every typology")
    return ok


def test_coherence_estimator():
    print("\n== 3. sample coherence estimator: finite-L bias (Sec. VIII) ==")
    cfg = C.default_cfg()
    rng = np.random.default_rng(1)
    table = SYN.CoherenceTable(cfg)
    M = 3000
    sc = make_scenario("AC", M, cfg)
    iu = np.triu_indices(cfg.physics.Bw, 1)
    lags = np.abs(iu[0] - iu[1])
    gt = cfg.physics.gamma0 * np.exp(-lags * 1.0)
    est = {}
    for L in (9, 121, 2000):
        sc["L"] = np.full(M, L)
        ev = np.ones((M, cfg.physics.Bw, 12, 12))
        out = SYN.synthesise_tile(sc, ev, rng, cfg, table)
        gh = SYN.estimate_coherence(out["slc"], sc["L"])
        est[L] = gh[:, iu[0], iu[1]].mean(axis=0)
        line = "  ".join(f"{iu[0][p]}-{iu[1][p]}:{gt[p]:.3f}/{est[L][p]:.3f}" for p in range(6))
        print(f"  L={L:5d} true/est  {line}")
    b9, b121, b2000 = (est[L][2] - gt[2] for L in (9, 121, 2000))
    print(f"  bias of pair 0-3:  L=9 {b9:.3f}   L=121 {b121:.3f}   L=2000 {b2000:.3f}")
    ok = (est[9][2] - gt[2] > 0.15 and b9 > b121 > b2000
          and abs(b121 / max(b9, 1e-9) - np.sqrt(9 / 121)) < 0.25
          and all(abs(est[L][5] - gt[5]) < 0.05 for L in (121, 2000)))
    print(OK if ok else BAD, "estimator behaviour consistent with Sec. VIII")
    return ok


def test_change_signatures():
    print("\n== 4. change signatures: cross (TC) vs block (DC) vs island (ADCS) ==")
    cfg = C.default_cfg()
    rng = np.random.default_rng(2)
    table = SYN.CoherenceTable(cfg)
    M = 1500
    cases = [("AC", 0, 0), ("NC", 0, 0), ("TC", 2, 2), ("DC", 2, 2), ("ADCS", 3, 2)]
    res = {}
    for kind, cls, icp in cases:
        sc = make_scenario(kind, M, cfg, cls=cls, icp=icp)
        ev = np.ones((M, cfg.physics.Bw, 8, 8))
        out = SYN.synthesise_tile(sc, ev, rng, cfg, table)
        res[kind] = SYN.estimate_coherence(out["slc"], sc["L"]).mean(axis=0)
    for kind, _, _ in cases:
        print(f"\n   {kind}:")
        for r in range(4):
            print("     " + "  ".join(f"{res[kind][r, c]:.3f}" for c in range(4)))
    ok = True
    # AC: single coherent block following gamma_t
    if not (res["AC"][0, 1] > 0.25 and res["AC"][0, 1] > res["AC"][0, 2] > res["AC"][0, 3]):
        ok = False
        print(BAD, "AC target does not follow gamma_t = exp(-|i-j| tau/tr)")
    # NC: no couple is coherent
    if not all(res["NC"][i, j] < 0.15 for i in range(4) for j in range(4) if i != j):
        ok = False
        print(BAD, "NC target shows coherence")
    # TC at icp=2: the cross is centred on epoch 2 - the couples 0-1 and 1-3
    # (lag 1 and lag 2) stay coherent, every couple involving epoch 2 collapses
    if not (res["TC"][0, 1] > 0.25 and res["TC"][1, 3] > 0.13
            and res["TC"][0, 2] < 0.2 and res["TC"][2, 3] < 0.2):
        ok = False
        print(BAD, "TC does not show the 'cross' structure of Eq. (12)")
    # DC at icp=2: block structure of Eq. (13)
    if not (res["DC"][0, 1] > 0.25 and res["DC"][2, 3] > 0.25
            and res["DC"][0, 2] < 0.15 and res["DC"][1, 3] < 0.15):
        ok = False
        print(BAD, "DC does not show the 'block' structure of Eq. (13)")
    # ADCS: independent coherent island
    if not (res["ADCS"][2, 3] > 0.4 and res["ADCS"][0, 2] < 0.15 and res["ADCS"][1, 3] < 0.15):
        ok = False
        print(BAD, "ADCS island is not an independent coherent object")
    print(OK if ok else BAD, "cross / block / island signatures reproduced")
    return ok


def test_timing():
    print("\n== 5. generator: patch shape, balance and throughput ==")
    cfg = C.default_cfg()
    rng = np.random.default_rng(3)
    table = SYN.CoherenceTable(cfg)
    t0 = time.time()
    x, y, icp, typ = SYN.build_patch_batch(8, cfg, rng, table)
    dt = time.time() - t0
    print(f"  x {x.shape} {x.dtype}   y {y.shape}   icp {icp.shape}   typ {typ.shape}")
    print(f"  {dt:.2f} s for 8 patches ({dt / 8 * 1000:.0f} ms/patch, "
          f"{8 / dt:.1f} patches/s)")
    print(f"  amplitude channels range [{x[:, :4].min():.3f}, {x[:, :4].max():.3f}]")
    print(f"  coherence channels range [{x[:, 4:].min():.3f}, {x[:, 4:].max():.3f}]")
    print(f"  class histogram: {np.bincount(y.ravel(), minlength=4)}")
    print(f"  typology histogram (0 AC,1 NC,2 TC,3 DC,4 ADCS): "
          f"{np.bincount(typ.ravel(), minlength=5)}")
    print(f"  coherence table entries: {len(table._cache)}")
    ok = (x.shape == (8, 10, 128, 128) and np.all(np.isfinite(x))
          and np.all((x >= 0.0) & (x <= 1.0)))
    print(OK if ok else BAD, "patch shape, finiteness and [0,1] normalisation")
    return ok


def test_regressions():
    """Regression checks for the implementation details fixed after review."""
    print("\n== 6. implementation regressions ==")
    cfg = C.default_cfg()
    rng = np.random.default_rng(17)
    table = SYN.CoherenceTable(cfg)
    ok = True

    # The lower Cholesky factor must reproduce Gamma directly.
    g = PH.build_gamma("AC", 4, 3, 0.0)
    L = PH.cholesky_unit_intensity(g)
    err = float(np.max(np.abs(L @ L.T - g)))
    print(f"  Cholesky max |LL^T-Gamma| = {err:.3e}")
    ok &= err < 1e-8

    # A multi-epoch TC keeps the unaffected block coherent but decorrelates
    # every pair involving the temporary event, including event-event pairs.
    gtc = SYN.effective_coherence(g, np.array([0, 1, 1, 0], dtype=bool),
                                  temporary=True)
    print("  multi-epoch TC g[1,2] =", round(float(gtc[1, 2]), 3))
    ok &= gtc[1, 2] <= C.EPSILON_LOW + 1e-12

    # ADCS generated through the real random path must be the 2-3 island.
    sc = SYN.sample_scenario(3000, rng, cfg, L_values=[9])
    ids = np.where(sc["kind"] == "ADCS")[0]
    if len(ids):
        ev = __import__("daninet.patterns", fromlist=["sample_patterns"]).sample_patterns(
            len(ids), 16, sc["icp"][ids], rng, 4)
        sub = {k: v[ids] for k, v in sc.items()}
        out = SYN.synthesise_tile(sub, ev, rng, cfg, table)
        island = float(out["gamma_true"][0, 2, 3])
        print(f"  ADCS count={len(ids)}  icp={np.unique(sub['icp'])}  g[2,3]={island:.3f}")
        ok &= np.all(sub["icp"] == 2) and island > 0.8
    else:
        ok = False
        print(BAD, "random generator produced no ADCS samples")

    # Labels must follow the spatial event, with an unchanged class-0
    # background rather than one class per whole pilot tile.
    x, y, _, _ = SYN.build_patch_batch(12, cfg, rng, table, L_values=[9])
    changed = float(np.mean(y > 0))
    print(f"  pixel-level changed-label fraction = {changed:.3f}")
    ok &= 0.30 < changed < 0.70 and np.unique(y).size == 4
    print(OK if ok else BAD, "fixed implementation paths")
    return bool(ok)


if __name__ == "__main__":
    results = {
        "backscatter": test_backscatter_models(),
        "scaling": test_scaling(),
        "coherence": test_coherence_estimator(),
        "signatures": test_change_signatures(),
        "timing": test_timing(),
        "regressions": test_regressions(),
    }
    print("\n===== SUMMARY =====")
    for k, v in results.items():
        print(f"  {k:14s} {'PASS' if v else 'FAIL'}")
    sys.exit(0 if all(results.values()) else 1)
