#!/usr/bin/env python3
"""Collect the base documents into docs/documents/files and write index.json.

Everything here is a copy, so the site repo stays self-contained: no build step
is needed on the Pages side and downloads work without JavaScript.

Usage:
    python3 daninet/tools/export_docs.py
    python3 daninet/tools/export_docs.py --date 2026-10-19
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from datetime import date
from pathlib import Path

MAX_BYTES = 4 * 1024 * 1024  # keep the published site small


def find_repo(start: Path) -> Path:
    for p in [start, *start.parents]:
        if (p / "AGENTS.md").is_file():
            return p
    return Path.cwd()


def human(n: int) -> str:
    for unit in ("B", "KB", "MB"):
        if n < 1024:
            return f"{n:.0f} {unit}"
        n /= 1024
    return f"{n:.1f} MB"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:12]


def main() -> int:
    repo = find_repo(Path(__file__).resolve().parent)
    ap = argparse.ArgumentParser(description="export documents for the site")
    ap.add_argument("--date", default=date.today().isoformat())
    ap.add_argument("--out", default="docs/documents/files")
    args = ap.parse_args()

    root = repo / args.out
    root.mkdir(parents=True, exist_ok=True)

    candidates = [
        ("复现说明", "daninet/README.md", "daninet-README.md", "markdown", "DANI-NET 复现的完整说明：公式对照、复现发现、结果表"),
        ("数据分析", "docs/content/analysis.md", "analysis.md", "markdown", "实验设置、对照结果与三条结论"),
        ("缺陷分析", "docs/content/gaps.md", "gaps.md", "markdown", "缺陷清单、所需资源、疑难点"),
    ]

    files = []
    for title, rel, name, kind, desc in candidates:
        src = repo / rel
        if not src.is_file():
            print(f"[skip] 缺少 {rel}")
            continue
        dst = root / name
        shutil.copy2(src, dst)
        files.append({"title": title, "name": name, "kind": kind, "desc": desc,
                      "size": dst.stat().st_size, "sha256": sha256(dst),
                      "updated": date.fromtimestamp(dst.stat().st_mtime).isoformat()})

    # code bundle (source only, no weights)
    pkg = repo / ".dsh" / "skills" / "project-report" / "scripts" / "package_code.py"
    if pkg.is_file():
        tmp = root / f"insar-affair-code-{args.date}.zip"
        try:
            subprocess.run([sys.executable, str(pkg), "--out", str(tmp)],
                           check=True, capture_output=True, text=True)
            files.append({"title": "复现代码包", "name": tmp.name, "kind": "zip",
                          "desc": "源码 + 说明，不含权重与数据", "size": tmp.stat().st_size,
                          "sha256": sha256(tmp), "updated": args.date})
        except subprocess.CalledProcessError as exc:
            print(f"[skip] 打包失败：{exc.stderr.strip()[:160]}")
    else:
        print("[skip] 未找到 package_code.py")

    files = [f for f in files if f["size"] <= MAX_BYTES] or files
    payload = {"generated_at": args.date, "files": files}
    (root / "index.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    total = sum(f["size"] for f in files)
    print(f"{len(files)} 个文档 -> {root}  合计 {human(total)}")
    for f in files:
        print(f"  {f['name']:<34} {human(f['size']):>9}  {f['sha256']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
