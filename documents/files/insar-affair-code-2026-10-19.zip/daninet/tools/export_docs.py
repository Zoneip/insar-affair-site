#!/usr/bin/env python3
"""Export the base documents into docs/documents/files as .md + .docx.

The site offers two actions per document: read in the browser (markdown rendered
by build_pages) and download as .docx (produced here with pandoc).  Everything
is a copy, so the site repo stays self-contained and needs no build step.

Usage:
    python3 daninet/tools/export_docs.py
    python3 daninet/tools/export_docs.py --date 2026-10-19
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from datetime import date
from pathlib import Path

MAX_BYTES = 4 * 1024 * 1024

DOCS = [
    ("复现说明", "daninet/README.md", "reproduction", "DANI-NET 复现的完整说明：公式对照、复现发现、结果表"),
    ("数据分析", "docs/content/analysis.md", "analysis", "实验设置、对照结果与三条结论"),
    ("缺陷分析", "docs/content/gaps.md", "gaps", "缺陷清单、所需资源、疑难点"),
]


def find_repo(start: Path) -> Path:
    for p in [start, *start.parents]:
        if (p / "AGENTS.md").is_file():
            return p
    return Path.cwd()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:12]


def md_to_docx(md: Path, out: Path) -> bool:
    """Convert with pandoc; the docx skill recommends validating the result."""
    try:
        subprocess.run(
            ["pandoc", "-f", "gfm", "-t", "docx", str(md), "-o", str(out)],
            check=True, capture_output=True, text=True,
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError) as exc:
        detail = getattr(exc, "stderr", "") or str(exc)
        print(f"[warn] docx 转换失败 {md.name}: {detail.strip()[:160]}")
        return False


def main() -> int:
    repo = find_repo(Path(__file__).resolve().parent)
    ap = argparse.ArgumentParser(description="export documents for the site")
    ap.add_argument("--date", default=date.today().isoformat())
    ap.add_argument("--out", default="docs/documents/files")
    args = ap.parse_args()

    root = repo / args.out
    root.mkdir(parents=True, exist_ok=True)

    files = []
    for title, rel, slug, desc in DOCS:
        src = repo / rel
        if not src.is_file():
            print(f"[skip] 缺少 {rel}")
            continue

        md_name = f"{slug}.md"
        md_dst = root / md_name
        shutil.copy2(src, md_dst)

        entry = {
            "title": title,
            "slug": slug,
            "desc": desc,
            "md": md_name,
            "size": md_dst.stat().st_size,
            "sha256": sha256(md_dst),
            "updated": args.date,
            "read": f"../read/{slug}.html",
        }

        docx_name = f"{slug}.docx"
        docx_dst = root / docx_name
        if md_to_docx(md_dst, docx_dst) and docx_dst.stat().st_size > 0:
            entry["docx"] = docx_name
            entry["docx_size"] = docx_dst.stat().st_size
        else:
            entry["docx"] = None

        files.append(entry)

    # code bundle (source only, no weights)
    pkg = repo / ".dsh" / "skills" / "project-report" / "scripts" / "package_code.py"
    if pkg.is_file():
        tmp = root / f"insar-affair-code-{args.date}.zip"
        try:
            subprocess.run([sys.executable, str(pkg), "--out", str(tmp)],
                           check=True, capture_output=True, text=True)
            files.append({"title": "复现代码包", "slug": "code", "desc": "源码 + 说明，不含权重与数据",
                          "md": None, "docx": None, "zip": tmp.name,
                          "size": tmp.stat().st_size, "sha256": sha256(tmp), "updated": args.date})
        except subprocess.CalledProcessError as exc:
            print(f"[skip] 打包失败：{exc.stderr.strip()[:160]}")

    if not files:
        raise SystemExit("没有可导出的文档")

    payload = {"generated_at": args.date, "files": files}
    (root / "index.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    total = sum(f["size"] for f in files)
    print(f"{len(files)} 个文档 -> {root}  合计 {total / 1024:.0f} KB")
    for f in files:
        extra = "docx" if f.get("docx") else ("zip" if f.get("zip") else "md only")
        print(f"  {f['slug']:<14} md {f['size']:>7} B  ({extra})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
