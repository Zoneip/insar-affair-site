#!/usr/bin/env python3
"""Export training runs into the data file used by the live dashboard.

The dashboard (``docs/live/``) is a static page, so "live" means: this script
rewrites ``docs/live/data.json`` while a run is in progress and the page polls
that file.  When nothing is training the page falls back to a replay of the
recorded history, which is what GitHub Pages serves.

Usage:
    python -m daninet.tools.export_live
    python -m daninet.tools.export_live --runs a3_amp_b16_b10_e15 --out docs/live/data.json
"""
from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path

# Label / device metadata is not stored in metrics.json, so it is pinned here.
RUN_META = {
    "final_augmented_v2": ("RTX 4060 · 5 blocks · fp32", "CUDA", 16),
    "a3_augmented_e15": ("Ascend910 ×1 · 5 blocks · fp32", "NPU", 16),
    "a3_amp_b16_e15": ("Ascend910 ×1 · 5 blocks · AMP", "NPU", 16),
    "a3_amp_b16_b10_e15": ("Ascend910 ×1 · 10 blocks · AMP", "NPU", 16),
    "a3_aug_e50": ("Ascend910 ×1 · 5 blocks · AMP · 50 ep", "NPU", 32),
}
DEFAULT_ORDER = [
    "a3_amp_b16_b10_e15",
    "a3_amp_b16_e15",
    "a3_aug_e50",
    "a3_augmented_e15",
    "final_augmented_v2",
]
LOG_TAIL = 40


def find_repo(start: Path) -> Path:
    for p in [start, *start.parents]:
        if (p / "AGENTS.md").is_file():
            return p
    return Path.cwd()


def load_run(path: Path) -> dict | None:
    metrics = path / "metrics.json"
    if not metrics.is_file():
        return None
    m = json.loads(metrics.read_text(encoding="utf-8"))
    name = m.get("run") or path.name
    label, device, batch = RUN_META.get(name, (name, "?", None))

    log_lines = []
    log = path / "log.txt"
    if log.is_file():
        text = log.read_text(encoding="utf-8", errors="replace").splitlines()
        log_lines = [ln.strip() for ln in text[-LOG_TAIL:] if ln.strip()]

    mtime = datetime.fromtimestamp(os.path.getmtime(metrics), tz=timezone.utc)
    return {
        "id": name,
        "label": label,
        "device": device,
        "batch": batch,
        "params": m.get("n_parameters"),
        "epochs": m.get("epochs_run"),
        "patches_per_epoch": m.get("train_patches_per_epoch"),
        "best_epoch": m.get("best_epoch"),
        "seconds": round(m.get("seconds", 0), 1),
        "train_L": m.get("train_L"),
        "test_L": m.get("test_L"),
        "history": [
            {
                "epoch": h["epoch"],
                "lr": h["lr"],
                "train_loss": round(h["train_loss"], 5),
                "val_loss": round(h["val_loss"], 5),
                "val_f1": round(h["val_f1_weighted"], 5),
                "val_acc": round(h["val_acc"], 5),
                "seconds": round(h.get("seconds", 0), 1),
            }
            for h in m.get("history", [])
        ],
        "tests": {
            k: {
                "f1_weighted": round(v["f1_weighted"], 5),
                "acc": round(v["acc"], 5),
                "p_d": [round(x, 4) for x in v.get("p_d", [])],
            }
            for k, v in m.get("tests", {}).items()
        },
        "log": log_lines,
        "updated": mtime.isoformat(timespec="seconds"),
        "updated_ts": mtime.timestamp(),
    }


def main() -> int:
    repo = find_repo(Path(__file__).resolve().parent)
    ap = argparse.ArgumentParser(description="export runs for the live dashboard")
    ap.add_argument("--runs", nargs="*", default=None, help="run names (default: curated order)")
    ap.add_argument("--out", default="docs/live/data.json")
    ap.add_argument("--repo", default=str(repo))
    ap.add_argument("--live", action="store_true",
                    help="标记为直播中（训练进程正在写 metrics 时使用；默认按回放处理）")
    args = ap.parse_args()

    root = Path(args.repo)
    runs_dir = root / "daninet" / "runs"
    names = args.runs or DEFAULT_ORDER
    runs = []
    for name in names:
        run = load_run(runs_dir / name)
        if run is not None:
            runs.append(run)

    if not runs:
        raise SystemExit(f"没有可用 run：{runs_dir}")

    # "live" is an explicit signal from the training side: file mtime alone would
    # turn true whenever this exporter runs, which would mislabel replays.
    live = bool(args.live)

    payload = {
        "generated_at": datetime.now(tz=timezone.utc).isoformat(timespec="seconds"),
        "live": live,
        "runs": runs,
    }
    out = Path(args.out)
    if not out.is_absolute():
        out = root / out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(runs)} runs -> {out}  ({out.stat().st_size / 1024:.1f} KB, live={live})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
