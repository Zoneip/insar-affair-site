"""CPU vs accelerator parity check and pure-compute throughput measurement.

The synthetic data generator is CPU bound, so end-to-end training throughput
mixes two very different things.  This tool separates them:

  1. parity   : same weights, same input, CPU (fp32) vs target device (fp32)
                forward pass -> max/mean absolute difference and pixel-wise
                argmax agreement;
  2. throughput: forward + backward + optimiser step on random tensors only,
                i.e. the number that decides how large a training run can be.

Usage:
    python -m daninet.tools.parity_check --device npu
    python -m daninet.tools.parity_check --device npu --batch 16 --steps 20
"""
from __future__ import annotations

import argparse
import json
import time

import torch
import torch.nn.functional as F

from daninet import config as C
from daninet.net.model import DANINet
from daninet.net.train import resolve_device


def sync(device: torch.device) -> None:
    if device.type == "npu":
        torch.npu.synchronize()
    elif device.type == "cuda":
        torch.cuda.synchronize()


def main() -> int:
    ap = argparse.ArgumentParser(description="CPU vs device parity + throughput")
    ap.add_argument("--device", default="npu", help="npu / cuda / cpu")
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--steps", type=int, default=10, help="timed training steps")
    ap.add_argument("--warmup", type=int, default=2)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default=None, help="optional json output path")
    args = ap.parse_args()

    cfg = C.default_cfg()
    torch.manual_seed(args.seed)
    ref = DANINet(cfg.net).eval()

    gen = torch.Generator().manual_seed(args.seed + 1)
    x = torch.randn(args.batch, 10, 128, 128, generator=gen)
    y = torch.randint(0, C.N_CLASSES, (args.batch, 128, 128), generator=gen)

    with torch.no_grad():
        _, logits_cpu = ref(x, return_logits=True)

    device = resolve_device(args.device)
    model = DANINet(cfg.net)
    model.load_state_dict(ref.state_dict())
    model.to(device).eval()

    with torch.no_grad():
        _, logits_dev = model(x.to(device), return_logits=True)
    logits_dev = logits_dev.float().cpu()

    diff = (logits_dev - logits_cpu).abs()
    denom = logits_cpu.abs().max().clamp_min(1e-12)
    parity = {
        "device": str(device),
        "batch": args.batch,
        "max_abs_diff": float(diff.max()),
        "mean_abs_diff": float(diff.mean()),
        "max_rel_diff": float(diff.max() / denom),
        "argmax_agreement": float((logits_dev.argmax(1) == logits_cpu.argmax(1)).float().mean()),
        "parameters": DANINet.n_parameters(model),
    }

    model.train()
    opt = torch.optim.Adam(model.parameters(), lr=1e-4)
    xb, yb = x.to(device), y.to(device)

    def step() -> None:
        opt.zero_grad(set_to_none=True)
        _, logits = model(xb, return_logits=True)
        loss = F.cross_entropy(logits, yb)
        loss.backward()
        opt.step()

    for _ in range(args.warmup):
        step()
    sync(device)

    t0 = time.time()
    for _ in range(args.steps):
        step()
    sync(device)
    elapsed = time.time() - t0

    throughput = {
        "steps": args.steps,
        "seconds": round(elapsed, 3),
        "patches_per_s": round(args.batch * args.steps / max(elapsed, 1e-9), 1),
        "patches_per_epoch_at_10k": round(10_000 / max(args.batch * args.steps / max(elapsed, 1e-9), 1e-9), 1),
    }

    result = {"parity": parity, "throughput": throughput}
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(result, fh, indent=2, ensure_ascii=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
