"""DANI-NET reproduction package (synthetic data generation + network + training)."""
from . import config, patterns, physics, synthetic  # noqa: F401

__all__ = ["config", "patterns", "physics", "synthetic"]
