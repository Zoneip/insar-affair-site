"""Synthetic amplitude-coherence tensor generator (Sec. III, IV, Alg. 1).

For every pixel the generator draws a physical scenario

    theta, theta_L, Delta_alpha, Bn/Bc, tau/tr, L, change class, spatial pattern

and synthesises Bw SLC samples according to

    S = xi o (V' d)                                        Eq. (16), (33)

with V = Chol(Gamma).T (Eq. (21)), d a white circular complex Gaussian process
(Eq. (19)) and xi the radar-brightness scaling of Eqs. (27)-(33).  The network
inputs are then built as in Fig. 2:

    * Bw amplitude samples |S_n|                             (Eq. (25))
    * Bw(Bw-1)/2 interferometric coherences |gamma_ij|, i<j  (Eq. (5))

Change phenomenology (Sec. II-B, IV-A)
--------------------------------------
* AC  (class 0) : always coherent, no change.
* NC  (class 0) : never coherent, no change - all the couples decorrelated.
* TC  (class i) : TEMPORARY change.  A contiguous group of epochs starting at
      the change point loses coherence with *all* the others while the target
      keeps its backscatter (Delta_alpha = 0); the epochs outside the event
      remain mutually coherent - this is the "cross" structure of Eq. (12).
* DC  (class i) : DEFINITIVE change.  Epochs from the change point to the end of
      the window form a new radar object, permanently decorrelated from the
      initial one (block structure of Eq. (13)) and with a new radar brightness
      (Delta_alpha != 0).
* ADCS (class 3): appearing-disappearing coherent scatterer - a short coherent
      island inside the window, an independent radar object.

The generator is vectorised over "pilot tiles" (Sec. V-D): all the pixels of a
tile share the physical parameters and differ only in their change pattern.
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np

from . import config as C
from . import patterns as PAT
from . import physics as PH

# number of baseline bins used to discretise Bn/Bc
N_BN = 41


# ---------------------------------------------------------------------------
# Coherence model: table of Cholesky factors (Eq. (5) x Eqs. (9)-(15))
# ---------------------------------------------------------------------------
def effective_coherence(g_tile: np.ndarray, on: np.ndarray, nc: bool = False,
                        adcs: bool = False, icp: int = 0, temporary: bool = False,
                        eps: float = C.EPSILON_LOW) -> np.ndarray:
    """Effective coherence matrix of Eq. (5) combined with Eqs. (9)-(15).

    Parameters
    ----------
    g_tile : [Bw, Bw]  gamma_0 * gamma_b * gamma_t of the fully coherent target
    on     : [Bw] bool True where the pixel already belongs to the NEW object
    nc     : never-coherent target (class 0, no change)
    adcs   : appearing-disappearing coherent scatterer
    icp    : change-point index (used by the ADCS island only)
    """
    Bw = g_tile.shape[0]
    if nc:
        g = np.full((Bw, Bw), eps)
        np.fill_diagonal(g, 1.0)
        return g
    on = np.asarray(on, dtype=bool)
    # A TC is an isolated temporary event: every pair involving an event
    # acquisition is decorrelated, including two acquisitions inside a longer
    # event.  A DC has two persistent radar objects, hence two coherent blocks.
    same = (np.outer(~on, ~on) if temporary
            else np.outer(on, on) | np.outer(~on, ~on))
    g = np.where(same, g_tile, eps)
    np.fill_diagonal(g, 1.0)
    if adcs:
        k = min(icp + 1, Bw - 1)
        g[k, :] = eps
        g[:, k] = eps
        g[k, k] = 1.0
        g[k, icp] = g[icp, k] = 1.0
    return g


class CoherenceTable:
    """Lazily cached Cholesky factors of the effective coherence matrices.

    The key of the table is (tau/tr bin, Bn/Bc bin, epoch-bit pattern, nc, adcs,
    icp): with Bw = 4 the epoch pattern has at most 16 realisations, so the
    table saturates after a few thousand patches and the generation becomes a
    pure array gather.
    """

    def __init__(self, cfg: C.Cfg):
        self.cfg = cfg
        self.Bw = cfg.physics.Bw
        self.tau_set: Tuple[int, ...] = tuple(sorted({int(t)
                                                     for t in cfg.physics.tau_ratio_set}))
        self.bn_grid = np.linspace(cfg.physics.bn_bc_min, cfg.physics.bn_bc_max, N_BN)
        self._g: Dict[Tuple[int, int], np.ndarray] = {}
        self._cache: Dict[int, Tuple[np.ndarray, np.ndarray]] = {}

    # -- tile-level coherence model gamma_0 * gamma_b * gamma_t -------------
    def gamma_tile(self, ti: int, bi: int) -> np.ndarray:
        k = (int(ti), int(bi))
        if k not in self._g:
            self._g[k] = PH.build_gamma("AC", self.Bw, self.tau_set[k[0]],
                                        float(self.bn_grid[k[1]]), self.cfg.physics.gamma0)
        return self._g[k]

    def tau_index(self, tau: np.ndarray) -> np.ndarray:
        lut = {t: i for i, t in enumerate(self.tau_set)}
        return np.array([lut[int(t)] for t in tau], dtype=np.int64)

    def bn_index(self, bn: np.ndarray) -> np.ndarray:
        return np.abs(self.bn_grid[None, :] - np.asarray(bn)[:, None]).argmin(axis=1)

    # -- effective coherence and its Cholesky factor ------------------------
    def get(self, ti: int, bi: int, bits: int, nc: int, adcs: int, icp: int,
            temporary: int = 0):
        key = ((((((int(ti) * N_BN + int(bi)) * (1 << self.Bw) + int(bits)) * 2
                  + int(nc)) * 2 + int(adcs)) * 2 + int(temporary))
               * (self.Bw if adcs else 1) + (int(icp) if adcs else 0))
        out = self._cache.get(key)
        if out is None:
            on = np.array([(bits >> k) & 1 for k in range(self.Bw)], dtype=bool)
            g = effective_coherence(self.gamma_tile(ti, bi), on, bool(nc), bool(adcs),
                                    int(icp), bool(temporary))
            V = PH.cholesky_unit_intensity(0.5 * (g + g.T) + np.eye(self.Bw) * 1e-12)
            out = (V, g)
            self._cache[key] = out
        return out


# ---------------------------------------------------------------------------
# Guide maps: the physical scenario of every tile
# ---------------------------------------------------------------------------
EPOCH_SET = {
    0: (),
    1: (1, 2, 3),
    2: (2, 3),
    3: (3,),
}


def sample_scenario(n_tiles: int, rng: np.random.Generator, cfg: C.Cfg,
                    L_values=None, change_only: bool = False) -> Dict[str, np.ndarray]:
    """Draw the physical parameters of ``n_tiles`` pilot tiles (Table II, Sec. V-D)."""
    ph = cfg.physics
    Bw = ph.Bw
    theta = rng.uniform(ph.theta_min_deg, ph.theta_max_deg, n_tiles)
    # theta_L ~ U[5, 80] deg (Table II); the local slope is theta_L = theta + alpha
    theta_l = rng.uniform(ph.thetaL_min_deg, ph.thetaL_max_deg, n_tiles)
    # Terrain-slope perturbation for a definitive change.  Draw it in the
    # admissible interval so the post-change local incidence remains in the
    # [5, 80] degree domain of Table II.
    da_min = ph.thetaL_min_deg - theta_l
    da_max = ph.thetaL_max_deg - theta_l
    delta_alpha = rng.uniform(da_min, da_max)
    bn = rng.uniform(ph.bn_bc_min, ph.bn_bc_max, n_tiles)
    tau_choices = np.array([int(t) for t in ph.tau_ratio_set])
    tau = tau_choices[rng.integers(0, len(tau_choices), n_tiles)]
    Lset = np.array(ph.L_train if L_values is None else L_values)
    L = Lset[rng.integers(0, len(Lset), n_tiles)]

    # ---- choose changed tiles so pixel-level labels are approximately 50/50
    # (Fig. 11).  The spatial patterns cover roughly 55% of a tile, hence most
    # tiles must carry a change for half of all pixels to be changed.
    p_changed_tile = 1.0 if change_only else min(
        1.0, C.P_CHANGE / max(cfg.data.expected_change_coverage, 1e-6))
    changed_tile = rng.random(n_tiles) < p_changed_tile
    cls = np.zeros(n_tiles, dtype=np.int64)
    n_changed = int(changed_tile.sum())
    if n_changed:
        if change_only:
            cls[changed_tile] = rng.choice((1, 2, 3), n_changed,
                                           p=(0.4, 0.4, 0.2))
        else:
            cls[changed_tile] = rng.integers(1, C.N_CLASSES, n_changed)
    kind = np.empty(n_tiles, dtype=object)      # AC | NC | TC | DC | ADCS
    definitive = np.zeros(n_tiles, dtype=bool)
    e_mask = np.zeros((n_tiles, Bw), dtype=bool)
    icp = np.zeros(n_tiles, dtype=np.int64)

    # class 0 : AC / NC
    z = np.where(cls == 0)[0]
    if len(z):
        is_nc = rng.random(len(z)) < 0.5
        kind[z] = np.where(is_nc, "NC", "AC")
    # classes 1-3 : TC / DC, plus ADCS inside class 3
    for c in (1, 2, 3):
        z = np.where(cls == c)[0]
        if len(z) == 0:
            continue
        icp[z] = c
        is_adcs = (c == 3) & (rng.random(len(z)) < 1.0 / 3.0)
        is_dc = rng.random(len(z)) < 0.5
        for i, idx in enumerate(z):
            if is_adcs[i]:
                kind[idx] = "ADCS"
                # ADCS is the short coherent island used in Fig. 4, between
                # acquisitions 2 and 3.  It is labelled class 3 but has its
                # own island timing rather than the DYN-3 endpoint.
                icp[idx] = 2
                e_mask[idx, 2:4] = True
            elif is_dc[i]:
                kind[idx] = "DC"
                definitive[idx] = True
                e_mask[idx, c:] = True
            else:
                kind[idx] = "TC"
                # contiguous event starting at the change point; if it stops
                # before the end of the window the target RECOVERS (Eq. (12))
                max_len = Bw - c
                ln = int(rng.integers(1, max_len + 1)) if max_len > 0 else 1
                e_mask[idx, c:c + ln] = True
    return dict(theta=theta, theta_l=theta_l, delta_alpha=delta_alpha,
                bn=bn, tau=tau, L=L, cls=cls,
                kind=kind, definitive=definitive, e_mask=e_mask, icp=icp)


# ---------------------------------------------------------------------------
# Core: synthesise the SLCs of one tile batch
# ---------------------------------------------------------------------------
def synthesise_tile(sc: Dict[str, np.ndarray], ev: np.ndarray,
                    rng: np.random.Generator, cfg: C.Cfg,
                    table: CoherenceTable) -> Dict[str, np.ndarray]:
    """Synthesise the SLCs of one pilot-tile batch.

    Parameters
    ----------
    sc : output of :func:`sample_scenario` (physical parameters, one per tile)
    ev : [M, Bw, T, T] spatial evolution of the change pattern (Fig. 5)

    Returns a dict with the complex SLC samples, the amplitude-coherence guide
    maps and the effective coherence matrices.
    """
    Bw = cfg.physics.Bw
    M, _, T, _ = ev.shape
    theta = np.deg2rad(sc["theta"])
    delta_deg = sc.get("delta_alpha", np.zeros(M, dtype=np.float64))
    delta = np.deg2rad(delta_deg)                             # tile-level Delta_alpha
    icp = sc["icp"]
    kind = sc["kind"]
    is_adcs = np.array([str(k) == "ADCS" for k in kind])
    is_nc = np.array([str(k) == "NC" for k in kind])
    is_tc = np.array([str(k) == "TC" for k in kind])
    is_dc = sc["definitive"]
    # TC has no slope change by definition; ADCS uses the new island object
    # brightness, while DC uses the persistent post-change slope.
    delta = np.where(is_dc | is_adcs, delta, 0.0)

    # ---- object membership: which epochs belong to the NEW radar object ----
    on = (ev > 0.5) & sc["e_mask"][:, :, None, None]          # [M, Bw, T, T]
    if is_adcs.any():
        # the island spans (icp, icp+1) and is an independent object
        for m in np.where(is_adcs)[0]:
            k0 = min(int(icp[m]), Bw - 1)
            on[m, k0] = ev[m, k0] > 0.5
            on[m, min(k0 + 1, Bw - 1)] = ev[m, k0] > 0.5

    # ---- per-pixel slope variation (the perturbation is not homogeneous) ---
    delta_px = delta[:, None, None] * (0.8 + 0.4 * rng.random((M, T, T)))

    # ---- radar brightness per (pixel, epoch) ------------------------------
    # a DEFINITIVE change introduces a new local incidence angle
    # theta_L + Delta_alpha (Eq. (29)); a TEMPORARY change keeps the same
    # backscatter (Delta_alpha = 0, Sec. II-B).  beta0 is therefore evaluated
    # only twice: on the initial surface and on the new one.
    theta_l0 = np.deg2rad(sc["theta_l"])
    b0_init = PH.beta0_db(theta, theta_l0, cfg.physics.backscatter_model)  # [M]
    # Eq. (29): sigma0 remains tied to the original incidence angle and only
    # the local-incidence sine ratio changes after a terrain-slope variation.
    b0_new = PH.beta0_db_shifted(theta[:, None, None], theta_l0[:, None, None],
                                 delta_px, cfg.physics.backscatter_model)
    change_px = on & is_dc[:, None, None, None]
    b0 = np.where(change_px, b0_new[:, None], b0_init[:, None, None, None])
    b0 = np.clip(b0, C.BETA0_DB_MIN, C.BETA0_DB_MAX)
    if is_adcs.any():
        # the island is a new object with its own brightness
        b0_ad = np.clip(PH.beta0_db_shifted(theta, theta_l0, delta,
                                            cfg.physics.backscatter_model),
                        C.BETA0_DB_MIN, C.BETA0_DB_MAX)
        for m in np.where(is_adcs)[0]:
            k0 = min(int(icp[m]), Bw - 1)
            b0[m, k0] = b0_ad[m]
            b0[m, min(k0 + 1, Bw - 1)] = b0_ad[m]
    beta0 = np.power(10.0, b0 / 10.0)

    # ---- Eq. (28): xi = sqrt(beta0) --------------------------------------
    # with V V^T normalised to unit intensity, S = xi o (V' d) gives E|S|^2 = beta0
    xi = np.sqrt(beta0)

    # ---- white complex Gaussian process d (Eq. (19)) ----------------------
    d = (rng.standard_normal((M, Bw, T, T)) + 1j * rng.standard_normal((M, Bw, T, T)))
    d /= np.sqrt(2.0)

    # ---- Cholesky factor of every pixel (cached on the epoch pattern) -----
    tau_idx = table.tau_index(sc["tau"])
    bn_idx = table.bn_index(sc["bn"])
    bits = np.zeros((M, T, T), dtype=np.int64)
    for k in range(Bw):
        bits |= (on[:, k].astype(np.int64) << k)

    Vall = np.empty((M * T * T, Bw, Bw), dtype=np.float64)
    Gtrue = np.empty((M, Bw, Bw), dtype=np.float64)
    # key = (((tau*N_BN + bn) * 2^Bw + epoch_bits) * 8
    #        + (nc*4 + adcs*2 + temporary)) * Bw + icp
    rep = lambda a: np.repeat(np.asarray(a).astype(np.int64), T * T)   # noqa: E731
    k1 = rep(tau_idx) * N_BN + rep(bn_idx)
    k3 = (rep(is_nc.astype(np.int64)) * 4 + rep(is_adcs.astype(np.int64)) * 2
          + rep(is_tc.astype(np.int64)))
    k4 = np.where(rep(is_adcs.astype(np.int64)) > 0, rep(icp), 0)
    key = (((k1 * (1 << Bw) + bits.ravel()) * 8 + k3) * Bw + k4)
    uk, inv = np.unique(key, return_inverse=True)
    # group the pixels by key in O(N log N) instead of scanning the array once
    # per key (the number of distinct keys grows with the parameter space)
    order = np.argsort(inv, kind='stable')
    sorted_inv = inv[order]
    bounds = np.searchsorted(sorted_inv, np.arange(len(uk) + 1))
    for u, kk in enumerate(uk):
        kk = int(kk)
        icp_k = kk % Bw
        rest = kk // Bw
        k3_k = rest % 8
        rest //= 8
        bits_k = rest % (1 << Bw)
        rest //= (1 << Bw)
        ti_k, bi_k = divmod(rest, N_BN)
        nc_k, adcs_k, temporary_k = k3_k // 4, (k3_k // 2) % 2, k3_k % 2
        if not adcs_k:
            icp_k = 0
        V, g = table.get(ti_k, bi_k, bits_k, nc_k, adcs_k, icp_k, temporary_k)
        sel = order[bounds[u]:bounds[u + 1]]
        Vall[sel] = V
        Gtrue[sel[0] // (T * T)] = g

    # ---- correlate and scale --------------------------------------------
    # each pixel has its own coherence matrix (its own change pattern), so the
    # correlation is applied pixel-wise: S[m,k,x,y] = sum_j V[m,x,y,k,j] d[m,j,x,y]
    Vall4 = Vall.reshape(M, T, T, Bw, Bw)
    # V is the lower Cholesky factor, so this is S = V d and
    # E[S S^H] = V V^T = Gamma.
    slc = np.einsum('mxykj,mjxy->mkxy', Vall4, d)
    slc = slc * xi
    return dict(slc=slc, beta0=b0, gamma_true=Gtrue, on=on, icp=icp, cls=sc["cls"])


# ---------------------------------------------------------------------------
# Coherence estimation (Eq. (5), [30], [34]-[37])
# ---------------------------------------------------------------------------
def estimate_coherence(slc: np.ndarray, L: np.ndarray) -> np.ndarray:
    """Sample coherence matrix over L looks, estimated on the SAME pixels.

    slc : [M, Bw, T, T] complex;  L : [M] number of looks
    returns |gamma_hat| : [M, Bw, Bw]

    The estimator is |sum_l S_i(l) S_j*(l)| / sqrt(sum_l |S_i|^2 sum_l |S_j|^2)
    and is applied on the very same pixels used for the products, as in
    [30], [34]-[37].
    """
    M, Bw = slc.shape[0], slc.shape[1]
    flat = slc.reshape(M, Bw, -1)
    P = flat.shape[-1]
    n = np.minimum(np.asarray(L), P).astype(np.int64)
    out = np.zeros((M, Bw, Bw), dtype=np.float64)
    for nv in np.unique(n):
        sel = np.where(n == nv)[0]
        x = flat[sel][:, :, :int(nv)]                    # [m, Bw, nv]
        num = np.einsum('mip,mjp->mij', x, np.conj(x))
        den = np.sqrt(np.einsum('mip,mip->mi', x, np.conj(x)).real)
        with np.errstate(invalid='ignore', divide='ignore'):
            g = np.abs(num) / (den[:, :, None] * den[:, None, :])
        out[sel] = np.clip(np.nan_to_num(g, nan=0.0), 0.0, 1.0)
    return out


# ---------------------------------------------------------------------------
# Patch assembly (Sec. IV-C, V-D)
# ---------------------------------------------------------------------------
def build_patch_batch(batch: int, cfg: C.Cfg, rng: np.random.Generator,
                      table: CoherenceTable, L_values=None, change_only: bool = False
                      ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Generate ``batch`` patches of the [10 x patch x patch] input tensor.

    Returns
    -------
    x    : [batch, 10, P, P] float32 - channels 0..Bw-1 amplitude, the remaining
           Bw(Bw-1)/2 the upper-triangular coherence samples (Fig. 2)
    y    : [batch, P, P] int64       - spatio-temporal change map (classes 0..3)
    icp  : [batch, P, P] int64       - change-point index of every pixel
    kind : [batch, P, P] uint8       - target typology (0 AC, 1 NC, 2 TC, 3 DC, 4 ADCS)
    """
    Bw = cfg.physics.Bw
    T = cfg.data.tile
    P = cfg.data.patch
    n_side = P // T
    n_tiles = batch * n_side * n_side

    sc = sample_scenario(n_tiles, rng, cfg, L_values=L_values,
                          change_only=change_only)

    # ---- spatio-temporal pattern of every tile (Sec. IV-B, Fig. 5) --------
    ev = PAT.sample_patterns(n_tiles, T, np.maximum(sc["icp"], 1), rng, Bw)
    out = synthesise_tile(sc, ev, rng, cfg, table)
    slc = out["slc"]
    gamma = estimate_coherence(slc, sc["L"])
    amp = np.abs(slc)

    # typology map for the diagnostics
    typ = np.zeros(n_tiles, dtype=np.uint8)
    for i, k in enumerate(sc["kind"]):
        typ[i] = {"AC": 0, "NC": 1, "TC": 2, "DC": 3, "ADCS": 4}[str(k)]

    up = np.triu_indices(Bw, k=1)
    x = np.zeros((batch, Bw + len(up[0]), P, P), dtype=np.float64)
    y = np.zeros((batch, P, P), dtype=np.int64)
    icp_map = np.zeros((batch, P, P), dtype=np.int64)
    kind_map = np.zeros((batch, P, P), dtype=np.uint8)
    for b in range(batch):
        for ty in range(n_side):
            for tx in range(n_side):
                k = (b * n_side + ty) * n_side + tx
                ys, xs = ty * T, tx * T
                x[b, :Bw, ys:ys + T, xs:xs + T] = amp[k]
                for ci, (i, j) in enumerate(zip(*up)):
                    x[b, Bw + ci, ys:ys + T, xs:xs + T] = gamma[k, i, j]
                # Labels are pixel-wise: class 0 is the unchanged background;
                # a dynamic class is assigned only where the spatial event is
                # present in at least one acquisition.
                changed = out["on"][k].any(axis=0)
                tile_label = np.zeros((T, T), dtype=np.int64)
                tile_label[changed] = sc["cls"][k]
                y[b, ys:ys + T, xs:xs + T] = tile_label
                icp_map[b, ys:ys + T, xs:xs + T] = sc["icp"][k]
                kind_map[b, ys:ys + T, xs:xs + T] = typ[k]

    # ---- amplitude normalisation between 0 and 1 (Sec. V-B) --------------
    lo, hi = cfg.data.amplitude_normalization
    a_db = 20.0 * np.log10(np.maximum(x[:, :Bw], 1e-12))
    x[:, :Bw] = np.clip((a_db - lo) / (hi - lo), 0.0, 1.0)
    return x.astype(np.float32), y, icp_map, kind_map
